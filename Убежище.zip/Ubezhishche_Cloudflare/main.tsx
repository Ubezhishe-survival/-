import {createRoot} from 'react-dom/client';import App from './app/page';
import './app/globals.css';
import './app/modern.css';
import './app/expansion.css';
import './app/refugees.css';
import './app/duo.css';
import './app/compact-tabs.css';
import './app/dense-ui.css';
createRoot(document.getElementById('root')!).render(<App/>);
