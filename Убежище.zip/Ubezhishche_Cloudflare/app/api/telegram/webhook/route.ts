import { env } from 'cloudflare:workers';
import { database } from '../../../../db';
import { constantTimeEqual } from '../../../../lib/telegram-auth';
import { botReply, type BotUpdate } from '../../../../lib/telegram-bot';
export async function POST(request:Request){
 const secret=env.TELEGRAM_WEBHOOK_SECRET;
 if(!secret||!env.TELEGRAM_BOT_TOKEN||!env.TELEGRAM_MINI_APP_URL)return new Response('Not configured',{status:503});
 const supplied=request.headers.get('X-Telegram-Bot-Api-Secret-Token')||'';
 if(!constantTimeEqual(secret,supplied))return new Response('Forbidden',{status:403});
 if(Number(request.headers.get('content-length'))>65536)return new Response('Payload too large',{status:413});
 try{
  const raw=await request.text();if(raw.length>65536)return new Response('Payload too large',{status:413});
  const update=JSON.parse(raw) as BotUpdate;
  if(!Number.isSafeInteger(update?.update_id))return new Response('Bad update',{status:400});
  const reply=botReply(update,env.TELEGRAM_MINI_APP_URL);if(!reply)return Response.json({ok:true});
  const inserted=await database().prepare('INSERT OR IGNORE INTO telegram_updates (update_id, received_at) VALUES (?,?)').bind(update.update_id,Date.now()).run();
  if(!inserted.meta.changes)return Response.json({ok:true});
  // Telegram executes this Bot API method as the response to its webhook.
  return Response.json(reply);
 }catch{console.error('Telegram webhook processing failed');return new Response('Retry later',{status:503})}
}
