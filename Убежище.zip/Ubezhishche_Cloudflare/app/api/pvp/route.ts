import {claimPvpPrize} from '../../../lib/pvp-rewards';
import { equippedSkin } from '../../../lib/skins';
import type { Game } from '../../../lib/game';
import { startPractice,tickOpponent } from '../../../lib/pvp-bots';
import { searchOpponent } from '../../../lib/pvp-matchmaking';
import { database } from '../../../db';
import { getPlayer, TelegramAuthError } from '../../../lib/player-auth';
import { applyMove, fighter, TURN_MS, type Duel, type Move } from '../../../lib/pvp';
type Row={id:string;host:string;guest:string|null;status:string;state:string;revision:number;updated_at:number};
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
const view=(r:Row,user:string)=>({id:r.id,status:r.status,revision:r.revision,updatedAt:r.updated_at,rewardClaimed:false,state:JSON.parse(r.state),seat:r.host===user?0:1});
async function expire(){const db=database(),cutoff=Date.now()-10*60_000;await db.batch([
 db.prepare("UPDATE pvp_matches SET status='cancelled',revision=revision+1 WHERE status='waiting' AND updated_at<?").bind(cutoff),
 db.prepare("DELETE FROM pvp_slots WHERE match_id IN (SELECT id FROM pvp_matches WHERE status IN ('cancelled','finished'))")]);}
export async function GET(request:Request){try{
 const user=await getPlayer(request);if(!user)return json({error:'Открой игру в Telegram.'},401);
 await expire();const db=database();
 let mine=await db.prepare('SELECT m.* FROM pvp_matches m JOIN pvp_slots s ON s.match_id=m.id WHERE s.user_id=?').bind(user.userId).first<Row>();
 if(mine?.status==='waiting')await db.prepare("UPDATE pvp_matches SET presence_at=? WHERE id=? AND host=? AND status='waiting'").bind(Date.now(),mine.id,user.userId).run();
 if(mine?.status==='waiting'&&(JSON.parse(mine.state) as Duel).searching){await searchOpponent(db,user.userId,user.displayName||'Выживший',Date.now());mine=await db.prepare('SELECT m.* FROM pvp_matches m JOIN pvp_slots s ON s.match_id=m.id WHERE s.user_id=?').bind(user.userId).first<Row>();}
 await tickOpponent(db,user.userId,Date.now());mine=await db.prepare('SELECT m.* FROM pvp_matches m JOIN pvp_slots s ON s.match_id=m.id WHERE s.user_id=?').bind(user.userId).first<Row>();
 const lobby=await db.prepare("SELECT id,state FROM pvp_matches WHERE status='waiting' AND host<>? ORDER BY updated_at DESC LIMIT 20").bind(user.userId).all<{id:string;state:string}>();
 const history=await db.prepare("SELECT * FROM pvp_matches WHERE (host=? OR guest=?) AND status='finished' ORDER BY updated_at DESC LIMIT 10").bind(user.userId,user.userId).all<Row>();
 const current=mine?view(mine,user.userId):null,recent=history.results.map(r=>view(r,user.userId));
 if(recent.length){const ids=recent.map(r=>'pvp:'+r.id);const claimed=await db.prepare(`SELECT id FROM supply_grants WHERE user_id=? AND id IN (${ids.map(()=>'?').join(',')})`).bind(user.userId,...ids).all<{id:string}>();const receipts=new Set(claimed.results.map(r=>r.id));for(const m of recent)m.rewardClaimed=receipts.has('pvp:'+m.id);}
 const rows=[...(mine?[mine]:[]),...history.results],ids=[...new Set(rows.flatMap(r=>[r.host,...(r.guest?[r.guest]:[])]))];
 if(ids.length){
  const saves=await db.prepare(`SELECT user_id,state FROM game_saves WHERE user_id IN (${ids.map(()=>'?').join(',')})`).bind(...ids).all<{user_id:string;state:string}>();
  const skins=new Map(saves.results.map(saved=>[saved.user_id,equippedSkin(JSON.parse(saved.state) as Game)]));
  for(const result of [...(current?[current]:[]),...recent]){const row=rows.find(r=>r.id===result.id)!;for(const index of [0,1] as const){const id=index===0?row.host:row.guest;if(id&&result.state.fighters[index])result.state.fighters[index].skin=skins.get(id)??'survivor';}}
 }

 return json({match:current,lobby:lobby.results.map(r=>({id:r.id,name:(JSON.parse(r.state) as Duel).fighters[0].name})),history:recent,now:Date.now()});
}catch(error){return failure(error)}}
export async function POST(request:Request){try{
 const user=await getPlayer(request);if(!user)return json({error:'Открой игру в Telegram.'},401);
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return json({error:'Недопустимый запрос.'},403);
 const p=await request.json() as {action:string;id?:string;revision?:number;move?:Move;botId?:string};
 const db=database(),now=Date.now();
 if(p.action==='practice'){await expire();const ok=await startPractice(db,user.userId,user.displayName||'Выживший',p.botId||'',now);return ok?json({ok:true}):json({error:'Соперник не найден.'},400);}
 if(p.action==='search'){await expire();await searchOpponent(db,user.userId,user.displayName||'Выживший',now);return json({ok:true});}
 if(p.action==='create'){
  await expire();const id=crypto.randomUUID().replaceAll('-','').slice(0,12).toUpperCase();
  const state:Duel={fighters:[fighter(user.displayName||'Выживший'),null],turn:0,deadline:0,winner:null,log:['Вызов открыт. Ожидаем второго игрока.']};
  await db.batch([db.prepare("INSERT INTO pvp_matches (id,host,status,state,revision,updated_at,presence_at) VALUES (?,?,'waiting',?,0,?,?)").bind(id,user.userId,JSON.stringify(state),now,now),db.prepare('INSERT INTO pvp_slots (user_id,match_id) VALUES (?,?)').bind(user.userId,id)]);
  return json({ok:true});
 }
 if(typeof p.id!=='string'||!/^[A-F0-9]{12}$/.test(p.id))return json({error:'Введи код дуэли из 12 символов.'},400);
 const r=await db.prepare('SELECT * FROM pvp_matches WHERE id=?').bind(p.id).first<Row>();if(!r)return json({error:'Дуэль не найдена.'},404);
 if(p.action==='reward'){const ok=await claimPvpPrize(db,r,user.userId,now);return ok?json({ok:true}):json({error:'Прогресс обновился. Повтори получение награды.'},409);}
 let state=JSON.parse(r.state) as Duel,status=r.status,guest=r.guest;
 if(p.action==='join'){
  if(r.host===user.userId)return json({error:'Нельзя сражаться с самим собой.'},400);
  if(r.status!=='waiting'||r.updated_at<now-10*60_000)return json({error:'Вызов уже занят или истёк.'},409);
  state.fighters[1]=fighter(user.displayName||'Выживший');state.turn=crypto.getRandomValues(new Uint8Array(1))[0]%2 as 0|1;state.deadline=now+TURN_MS;state.log=['Оба бойца на арене. Первый ход выбран случайно.'];status='active';guest=user.userId;
 }else{
  if(r.host!==user.userId&&r.guest!==user.userId)return json({error:'Это чужая дуэль.'},403);
  if(p.revision!==r.revision)return json({error:'Бой обновился. Повтори действие.'},409);
  const seat=r.host===user.userId?0:1;
  if(p.action==='cancel'&&status==='waiting')status='cancelled';
  else if(status==='active'){
   if(p.action==='surrender'){state.winner=seat===0?1:0;state.log.unshift(`${state.fighters[seat]!.name} отступил.`);status='finished';}
   else if(p.action==='timeout'){
    if(state.bot||now<state.deadline||state.turn===seat)return json({error:'Ожидаем ход соперника.'},400);
    state.winner=seat;state.log.unshift('Соперник пропустил ход. Техническая победа.');status='finished';
   }else if(p.action==='move'){state=applyMove(state,seat,p.move!,now);if(state.winner!==null)status='finished';}
   else return json({error:'Действие недоступно.'},400);
  }else return json({error:'Дуэль уже завершена.'},409);
 }
 if(state.bot&&status==='active'&&state.turn===1)state.botDue=now+1800;
 const statements=[db.prepare('UPDATE pvp_matches SET state=?,status=?,guest=?,revision=revision+1,updated_at=? WHERE id=? AND revision=? AND status=?').bind(JSON.stringify(state),status,guest,now,r.id,r.revision,r.status)];
 if(p.action==='join')statements.push(db.prepare('INSERT INTO pvp_slots (user_id,match_id) SELECT ?,? WHERE changes()=1').bind(user.userId,r.id));
 if(status==='finished'||status==='cancelled')statements.push(db.prepare("DELETE FROM pvp_slots WHERE match_id=? AND EXISTS (SELECT 1 FROM pvp_matches WHERE id=? AND status IN ('finished','cancelled'))").bind(r.id,r.id));
 const results=await db.batch(statements);if(!results[0].meta.changes)return json({error:'Бой обновился. Повтори действие.'},409);
 return json({ok:true});
}catch(error){return failure(error)}}
function failure(error:unknown){if(error instanceof TelegramAuthError)return json({error:error.message},401);if(error instanceof SyntaxError)return json({error:'Некорректный запрос.'},400);if(error instanceof Error&&/UNIQUE constraint/.test(error.message))return json({error:'У тебя уже есть дуэль. Обнови арену.'},409);if(error instanceof Error&&['Награда доступна','Сначала загрузи','Бой ещё','Сейчас ход','Время хода','Неизвестный приём','Для мощного','Нужно','Аптечка использована','Здоровье полное'].some(s=>error.message.startsWith(s)))return json({error:error.message},400);console.error('PvP',error);return json({error:'Арена недоступна. Попробуй обновить через несколько секунд.'},503)}
