export async function GET(){return Response.json({error:'Рейтинг арены закрыт. За победы теперь выдаются припасы.'},{status:410,headers:{'Cache-Control':'no-store'}})}
