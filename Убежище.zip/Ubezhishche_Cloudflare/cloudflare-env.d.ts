declare namespace Cloudflare {interface Env {DB:D1Database;ASSETS:Fetcher;TELEGRAM_BOT_TOKEN:string;TELEGRAM_WEBHOOK_SECRET:string;TELEGRAM_MINI_APP_URL:string}}
