"""Shelter Telegram connector: hidden input and safe, specific diagnostics.

No extra packages. No credentials are written to files or diagnostic output.
Use --diagnose to check Telegram and Worker without changing bot settings.
"""
import getpass
import json
import os
import re
import socket
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
import warnings


class SetupError(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Do not forward credentials to a redirected destination.
        return None


def safe_detail(error, secrets):
    text = str(error)
    for value in secrets:
        if value:
            text = text.replace(value, '[HIDDEN]')
            text = text.replace(urllib.parse.quote(value, safe=''), '[HIDDEN]')
    text = re.sub(r'(?i)(?:https?|socks5h?)://\S+', '[URL HIDDEN]', text)
    text = re.sub(r'\b\d+:[A-Za-z0-9_-]+', '[TOKEN HIDDEN]', text)
    text = ''.join(c if c.isprintable() else ' ' for c in text)
    return text[:250]


def network_error(error, secrets):
    reason = error.reason if isinstance(error, urllib.error.URLError) else error
    detail = safe_detail(reason, secrets)
    if isinstance(reason, ssl.SSLCertVerificationError) or 'CERTIFICATE_VERIFY_FAILED' in str(reason):
        return SetupError('[E_SSL_CERT] Python не доверяет HTTPS-сертификату. '
                          'Проверьте дату и время Windows; попробуйте другую сеть. '
                          'Не отключайте проверку сертификатов. Детали: ' + detail)
    if isinstance(reason, socket.gaierror):
        return SetupError('[E_DNS] Не удалось определить адрес сервера. '
                          'Проверьте подключение и DNS/VPN. Детали: ' + detail)
    if isinstance(reason, (TimeoutError, socket.timeout)):
        return SetupError('[E_TIMEOUT] Сервер не ответил за 25 секунд. '
                          'Попробуйте другое подключение или сервер VPN. Детали: ' + detail)
    if isinstance(reason, ssl.SSLError):
        return SetupError('[E_SSL] Сбой защищённого соединения Python. Детали: ' + detail)
    return SetupError('[E_NETWORK] Ошибка HTTPS-запроса Python: '
                      + type(reason).__name__ + '. ' + detail)


def http_error(code, service, response_body=''):
    cloudflare_code = re.search(r'\berror code:\s*(\d{4,5})\b', response_body, flags=re.IGNORECASE)
    if cloudflare_code:
        number = cloudflare_code.group(1)
        return SetupError('[E_CLOUDFLARE_' + number + '] Запрос отклонён Cloudflare до обработки игрой. '
                          'Замена webhook-секрета эту блокировку не исправляет. Пришлите этот код.')
    if 300 <= code < 400:
        hint = 'Получено перенаправление. Нужен прямой публичный HTTPS-адрес без страницы входа.'
    elif service == 'Telegram' and code in (401, 404):
        hint = 'Проверьте токен именно этого бота в BotFather и скопируйте его целиком.'
    elif service == 'Webhook' and code == 403:
        hint = ('Сервер запретил запрос: проверьте совпадение TELEGRAM_WEBHOOK_SECRET '
                'с пунктом 7 и ограничения доступа Cloudflare.')
    elif service == 'Webhook' and code == 503:
        hint = 'Проверьте секреты TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET и логи Worker.'
    elif service == 'Webhook' and code in (404, 405):
        hint = 'Проверьте реальный адрес после npm run deploy и публикацию server/worker.ts.'
    elif code == 429:
        hint = 'Слишком много запросов. Подождите несколько минут перед повторным запуском.'
    else:
        hint = 'Пришлите код ошибки и название этапа для диагностики.'
    return SetupError('[E_' + service.upper() + '_HTTP_' + str(code) + '] ' + hint)


def read_value(key, prompt, hidden=False):
    value = os.environ.get(key)
    if value:
        print('Используется переменная окружения ' + key + ' (значение скрыто).')
    elif hidden:
        with warnings.catch_warnings():
            warnings.simplefilter('error', getpass.GetPassWarning)
            try:
                value = getpass.getpass(prompt)
            except getpass.GetPassWarning:
                raise SetupError('[E_INPUT] Запустите файл в обычном терминале или через CONNECT_BOT.cmd.') from None
    else:
        value = input(prompt)
    return value.strip()


def validate_values(token, secret, url):
    if not re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]+', token):
        raise SetupError('[E_TOKEN_FORMAT] Вставьте только токен из BotFather: цифры, двоеточие и ключ. '
                         'Без кавычек, слова bot, ссылки и пробелов внутри.')
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,256}', secret):
        raise SetupError('[E_SECRET_FORMAT] Нужен тот же секрет из пункта 7: латинские буквы, цифры, _ или -.')
    try:
        parsed = urllib.parse.urlsplit(url)
        valid = (parsed.scheme == 'https' and parsed.hostname and not parsed.username
                 and not parsed.password and not parsed.query and not parsed.fragment
                 and parsed.path in ('', '/') and parsed.port in (None, 443)
                 and not any(c.isspace() for c in url))
    except ValueError:
        valid = False
    if not valid:
        raise SetupError('[E_URL] Вставьте корневой HTTPS-адрес Worker после npm run deploy, '
                         'без /api/telegram/webhook и других путей.')
    return url.rstrip('/')


def run(diagnose=False, values=None):
    print('УБЕЖИЩЕ — подключение Telegram, версия 1.3')
    print('Python ' + sys.version.split()[0] + ' / ' + ssl.OPENSSL_VERSION)
    if values is None:
        print('Токен и секрет не отображаются при вводе — это нормально.')
        token = read_value('TELEGRAM_BOT_TOKEN', 'Токен бота: ', True)
        secret = read_value('TELEGRAM_WEBHOOK_SECRET', 'Тот же секрет из пункта 7: ', True)
        url = read_value('TELEGRAM_MINI_APP_URL', 'Реальный HTTPS-адрес Worker: ')
    else:
        # GUI values are explicit. Ignore stale environment credentials.
        token, secret, url = (value.strip() for value in values)
        print('Используются значения из окна ввода. Токен и секрет скрыты.')
    url = validate_values(token, secret, url)
    secrets = (token, secret)
    opener = urllib.request.build_opener(NoRedirect())
    if any(urllib.request.getproxies().get(k) for k in ('http', 'https', 'all')):
        print('Python обнаружил настройки прокси. Адрес и пароль прокси скрыты.')

    def request_json(target, payload, service, headers=None):
        # Identify this installer explicitly. The default Python-urllib agent
        # triggered Cloudflare error 1010 on the customer's public Worker.
        request_headers = {'Content-Type': 'application/json', 'User-Agent': 'UbezhishcheSetup/1.3'}
        request_headers.update(headers or {})
        try:
            req = urllib.request.Request(target, data=json.dumps(payload).encode('utf-8'),
                                         headers=request_headers, method='POST')
            with opener.open(req, timeout=25) as response:
                result = json.load(response)
        except urllib.error.HTTPError as error:
            try:
                body = error.read(4096).decode('utf-8', errors='replace')
            except (OSError, AttributeError, TypeError):
                body = ''
            # Only emit a recognized numeric Cloudflare code, never raw HTML.
            raise http_error(error.code, service, body) from None
        except (urllib.error.URLError, OSError) as error:
            raise network_error(error, secrets) from None
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise SetupError('[E_' + service.upper() + '_NOT_JSON] '
                             'В ответе нет ожидаемого JSON. Возможна страница входа, '
                             'фильтрация соединения или неверный адрес.') from None
        except (ValueError, UnicodeError):
            raise SetupError('[E_REQUEST_FORMAT] Проверьте формат токена, секрета и адреса.') from None
        if not isinstance(result, dict):
            raise SetupError('[E_RESPONSE_FORMAT] Сервер вернул неожиданный формат ответа.')
        return result

    def call(method, payload=None):
        result = request_json('https://api.telegram.org/bot' + token + '/' + method,
                              payload or {}, 'Telegram')
        if result.get('ok') is not True:
            code = result.get('error_code')
            if isinstance(code, int):
                raise http_error(code, 'Telegram')
            raise SetupError('[E_TELEGRAM_RESPONSE] Telegram отклонил ' + method + '.')
        if 'result' not in result:
            raise SetupError('[E_RESPONSE_FORMAT] В ответе Telegram нет result.')
        return result['result']

    print('[1/5] Проверка токена — getMe...')
    me = call('getMe')
    if not isinstance(me, dict) or not me.get('username'):
        raise SetupError('[E_RESPONSE_FORMAT] Telegram не вернул username бота.')
    print('Telegram ответил. Бот: @' + me['username'])
    hook = url + '/api/telegram/webhook'
    print('[2/5] Проверка существующего webhook...')
    previous = call('getWebhookInfo')
    if not isinstance(previous, dict):
        raise SetupError('[E_RESPONSE_FORMAT] Неожиданный ответ getWebhookInfo.')
    if previous.get('url') and previous['url'] != hook:
        raise SetupError('[E_OTHER_WEBHOOK] Бот уже подключён к другому адресу. '
                         'Настройки не изменены. Используйте нового бота или отдельно согласуйте перенос.')
    print('[3/5] Проверка опубликованного Worker и секрета...')
    ready = request_json(hook, {'update_id': 0}, 'Webhook',
                         {'X-Telegram-Bot-Api-Secret-Token': secret})
    if ready.get('ok') is not True:
        raise SetupError('[E_WEBHOOK_RESPONSE] Worker не подтвердил готовность. Настройки бота не изменены.')
    if diagnose:
        print('ПРОВЕРКА ПРОЙДЕНА. Настройки бота не изменялись.')
        return
    print('[4/5] Настройка команд, описания, кнопки и webhook...')
    call('setMyCommands', {'commands': [
        {'command': 'start', 'description': 'Войти в убежище'},
        {'command': 'play', 'description': 'Продолжить игру'},
        {'command': 'help', 'description': 'Как выжить'}]})
    call('setMyDescription', {'description': 'После сигнала — атмосферная игра о выживании. Развивай убежище, исследуй город, принимай решения и найди источник таинственного сигнала.'})
    call('setMyShortDescription', {'short_description': 'Твоё убежище. Твоя частота. Твой шанс выжить.'})
    call('setChatMenuButton', {'menu_button': {'type': 'web_app', 'text': 'Играть', 'web_app': {'url': url}}})
    call('setWebhook', {'url': hook, 'secret_token': secret, 'allowed_updates': ['message'], 'drop_pending_updates': False})
    print('[5/5] Проверка сохранённых настроек...')
    actual = call('getWebhookInfo')
    menu = call('getChatMenuButton')
    if not isinstance(actual, dict) or actual.get('url') != hook:
        raise SetupError('[E_WEBHOOK_CONFIRM] Telegram не подтвердил новый webhook.')
    if not isinstance(menu, dict) or menu.get('web_app', {}).get('url') != url:
        raise SetupError('[E_MENU_CONFIRM] Telegram не подтвердил адрес кнопки.')
    print('ПОДКЛЮЧЕНО: https://t.me/' + me['username'])
    print('Откройте бота, отправьте /start и нажмите «Войти в убежище».')


def main(values=None):
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(errors='replace')
    try:
        if any(arg != '--diagnose' for arg in sys.argv[1:]):
            raise SetupError('[E_ARGUMENT] Запускайте без аргументов или с --diagnose. Не передавайте токен в команде.')
        run('--diagnose' in sys.argv[1:], values)
        return 0
    except SetupError as error:
        print('\n' + str(error), file=sys.stderr)
        print('Пришлите фото этапа и кода ошибки. Токен и секрет присылать не нужно.', file=sys.stderr)
        return 1
    except (KeyboardInterrupt, EOFError):
        print('\nВвод отменён. Запустите подключение снова в терминале.', file=sys.stderr)
        return 1
    except Exception as error:
        # Never output a raw exception/traceback that might contain credentials.
        print('[E_UNEXPECTED] ' + type(error).__name__ + '. Пришлите фото этого сообщения.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
