"""Native form for connection credentials; clipboard paste avoids getpass input.

Values are kept in memory, never written to disk, arguments, or environment.
"""
import importlib.util
from pathlib import Path
import re
import sys


def token_feedback(raw):
    token = raw.strip()
    if not token:
        return False, 'Поле пустое. Скопируйте токен в BotFather и нажмите «Вставить» справа.'
    if '\x16' in token:
        return False, 'Вместо вставки получен символ Ctrl+V. Нажмите кнопку «Вставить» справа.'
    if re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]+', token):
        return True, 'Вставлено символов: ' + str(len(token)) + '. Формат подходит; действительность проверит Telegram.'
    if ':' not in token:
        return False, 'Вставлено символов: ' + str(len(token)) + '. Нет двоеточия между номером бота и ключом.'
    if token.count(':') != 1:
        return False, 'Обнаружено несколько двоеточий. Скопируйте только один токен без текста сообщения.'
    left, right = token.split(':', 1)
    if not left or not left.isascii() or not left.isdigit():
        return False, 'До двоеточия должны быть только цифры. Уберите подпись, слово bot или ссылку.'
    if not right:
        return False, 'После двоеточия нет ключа. Скопируйте токен целиком.'
    invalid = [c for c in right if not re.fullmatch(r'[A-Za-z0-9_-]', c)]
    if invalid:
        codes = ', '.join(sorted({'U+' + format(ord(c), '04X') for c in invalid})[:4])
        return False, 'В ключе есть лишние символы (коды: ' + codes + '). Нажмите «Вставить» после копирования самого токена.'
    return False, 'Формат не распознан. Скопируйте сам токен без кавычек и подписи.'


def collect_values(connector):
    try:
        import tkinter as tk
        from tkinter import ttk, messagebox
    except ImportError:
        print('[E_GUI_TK] В этой установке Python нет tkinter. Пришлите этот код; игру переустанавливать не нужно.')
        return None
    try:
        root = tk.Tk()
    except tk.TclError:
        print('[E_GUI_START] Не удалось открыть окно. Запускайте CONNECT_BOT.cmd на рабочем столе Windows.')
        return None
    root.title('Убежище — подключение бота 1.3')
    root.geometry('780x660')
    root.minsize(720, 660)
    def callback_error(error_type, error, traceback):
        print('[E_GUI_CALLBACK] ' + error_type.__name__ + '. Пришлите этот код.')
        messagebox.showerror('Ошибка окна', 'Не удалось выполнить действие. Код E_GUI_CALLBACK.\nТокен и секрет присылать не нужно.', parent=root)
    root.report_callback_exception = callback_error
    root.option_add('*Font', ('Segoe UI', 11))
    root.columnconfigure(0, weight=1)
    result = []
    frame = ttk.Frame(root, padding=22)
    frame.grid(sticky='nsew')
    frame.columnconfigure(0, weight=1)
    ttk.Label(frame, text='Подключение Telegram-бота', font=('Segoe UI', 18, 'bold')).grid(row=0, column=0, columnspan=2, sticky='w', pady=(0, 10))
    ttk.Label(frame, text='Скопируйте значение и нажмите «Вставить» рядом с нужным полем.\nВвод в консоли больше не используется. Токен и секрет скрыты звёздочками.', wraplength=710).grid(row=1, column=0, columnspan=2, sticky='w', pady=(0, 16))
    token = tk.StringVar(root)
    secret = tk.StringVar(root)
    url = tk.StringVar(root)
    feedback = tk.StringVar(root)
    fields = []

    def paste(variable):
        try:
            text = root.clipboard_get()
        except tk.TclError:
            messagebox.showinfo('Буфер обмена пуст', 'Сначала скопируйте нужное значение, затем нажмите «Вставить».', parent=root)
            return
        variable.set(text.strip())

    def field(row, title, variable, masked=False):
        ttk.Label(frame, text=title).grid(row=row, column=0, columnspan=2, sticky='w', pady=(8, 4))
        entry = ttk.Entry(frame, textvariable=variable, show='*' if masked else '', width=58)
        entry.grid(row=row + 1, column=0, sticky='ew', ipady=5)
        ttk.Button(frame, text='Вставить', command=lambda: paste(variable)).grid(row=row + 1, column=1, padx=(12, 0), sticky='ns')
        fields.append(entry)
        return entry

    field(2, '1. Токен бота из BotFather', token, True)
    status = ttk.Label(frame, textvariable=feedback, wraplength=710)
    status.grid(row=4, column=0, columnspan=2, sticky='w', pady=(5, 5))

    def refresh(*unused):
        valid, text = token_feedback(token.get())
        feedback.set(text)
        status.configure(foreground='#15703b' if valid else '#9c4510')

    token.trace_add('write', refresh)
    refresh()
    field(5, '2. Тот же секрет из пункта 7', secret, True)
    ttk.Label(frame, text='Значение TELEGRAM_WEBHOOK_SECRET, сохранённое в Cloudflare.', wraplength=710).grid(row=7, column=0, columnspan=2, sticky='w', pady=(5, 5))
    field(8, '3. Реальный HTTPS-адрес игры после npm run deploy', url)
    ttk.Label(frame, text='Вставьте адрес вашего Worker целиком. Без /api/telegram/webhook.', wraplength=710).grid(row=10, column=0, columnspan=2, sticky='w', pady=(5, 15))
    ttk.Label(frame, text='После проверки будут настроены команды, описание, кнопка «Играть»\nи подключение этого бота к вашей игре.', wraplength=710).grid(row=11, column=0, columnspan=2, sticky='w', pady=(0, 12))

    def submit():
        valid, text = token_feedback(token.get())
        if not valid:
            messagebox.showinfo('Проверьте поле токена', text, parent=root)
            return
        values = tuple(v.get().strip() for v in (token, secret, url))
        try:
            connector.validate_values(*values)
        except connector.SetupError as error:
            messagebox.showinfo('Проверьте данные', str(error), parent=root)
            return
        result.append(values)
        for variable in (token, secret, url):
            variable.set('')
        root.destroy()

    ttk.Button(frame, text='Подключить бота', command=submit).grid(row=12, column=0, columnspan=2, sticky='ew', ipady=9)
    ttk.Label(frame, text='Результат появится в окне терминала. Значения не записываются в файлы.', wraplength=710).grid(row=13, column=0, columnspan=2, sticky='w', pady=(10, 0))
    fields[0].focus_set()
    root.mainloop()
    return result[0] if result else None


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(errors='replace')
    spec = importlib.util.spec_from_file_location('shelter_connector', Path(__file__).with_name('connect-telegram.py'))
    connector = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(connector)
    print('Версия 1.3. Открываю окно ввода. После заполнения результат появится здесь.')
    try:
        values = collect_values(connector)
        if values is None:
            print('Подключение не выполнялось.')
            return 1
        return connector.main(values=values)
    except Exception as error:
        # Exception strings can contain Tcl command arguments, including fields.
        print('[E_GUI] ' + type(error).__name__ + '. Пришлите этот код.')
        return 1


if __name__ == '__main__':
    sys.exit(main())
