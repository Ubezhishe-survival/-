import {readFile,writeFile} from 'node:fs/promises';
import {createInterface} from 'node:readline/promises';
const rl=createInterface({input:process.stdin,output:process.stdout});
try{
 const name=(await rl.question('Имя Worker (латиница, например my-shelter): ')).trim();
 const db=(await rl.question('Имя созданной D1 базы: ')).trim();
 const id=(await rl.question('database_id базы (UUID): ')).trim();
 const url=(await rl.question('HTTPS адрес Worker (https://имя.поддомен.workers.dev): ')).trim().replace(/\/$/,'');
 const bot=(await rl.question('Username своего Telegram-бота без @: ')).trim().replace(/^@/,'');
 if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(name)||!db||!/^[a-f0-9-]{36}$/i.test(id)||!/^https:\/\/[^/?#]+$/.test(url)||!/^\w{5,32}$/.test(bot))throw Error('Некорректные настройки. Запусти setup ещё раз.');
 const c=JSON.parse(await readFile('wrangler.json','utf8'));c.name=name;c.d1_databases[0].database_name=db;c.d1_databases[0].database_id=id;c.vars.TELEGRAM_MINI_APP_URL=url;
 await writeFile('wrangler.json',JSON.stringify(c,null,2)+'\n');await writeFile('.env',`VITE_TELEGRAM_BOT_USERNAME=${bot}\n`);console.log('Настройки сохранены. Продолжи по инструкции с миграции базы.');
}finally{rl.close()}
