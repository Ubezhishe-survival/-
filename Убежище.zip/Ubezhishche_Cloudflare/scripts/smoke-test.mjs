// Run against local wrangler dev only, with the test .dev.vars from README.
import assert from 'node:assert/strict';import {createHmac} from 'node:crypto';
const base='http://127.0.0.1:8787',token='local-test-token';
function init(id,date=Math.floor(Date.now()/1000)) {const p=new URLSearchParams({auth_date:String(date),user:JSON.stringify({id,first_name:'Local tester'})});const check=[...p].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');const key=createHmac('sha256','WebAppData').update(token).digest();p.set('hash',createHmac('sha256',key).update(check).digest('hex'));return p.toString()}
async function api(path,id,body,status=200,extra={}){const r=await fetch(base+path,{method:body?'POST':'GET',headers:{...(id?{'X-Telegram-Init-Data':init(id)}:{}),'Content-Type':'application/json',...extra},...(body?{body:JSON.stringify(body)}:{})});assert.equal(r.status,status,`${path}: ${await r.clone().text()}`);return r.headers.get('content-type')?.includes('json')?r.json():r.text()}
assert.equal((await fetch(base)).status,200);
await api('/api/game',null,null,401);
await api('/api/game',null,null,401,{'X-Telegram-Init-Data':'hash=bad'});
await api('/api/game',null,null,401,{'X-Telegram-Init-Data':init(999,1)});
await api('/api/game',null,null,401,{'x-oai-user-id':'fake-user'});
const id=Date.now(),first=await api('/api/game',id),second=await api('/api/game',id+1);assert.equal(first.revision,0);assert.equal(second.revision,0);
const next=await api('/api/game',id,{revision:0,action:{type:'training',choice:'start'}});assert.equal(next.revision,1);
await api('/api/game',id,{revision:0,action:{type:'training',choice:'skip'}},409);
assert.equal((await api('/api/game',id+1)).revision,0);
await api('/api/game',id,{revision:1,action:{type:'training',choice:'skip'}},403,{Origin:'https://foreign.example'});
for(const path of ['/api/pvp','/api/duo','/api/raid'])await api(path,id);
await api('/api/missing',id,null,404);
assert.equal((await fetch(base+'/api/game',{method:'DELETE'})).status,405);
await api('/api/telegram/webhook',null,{update_id:1},403);
const reply=await api('/api/telegram/webhook',null,{update_id:id,message:{text:'/start',chat:{id:123,type:'private'}}},200,{'X-Telegram-Bot-Api-Secret-Token':'local-test-secret'});assert.equal(reply.method,'sendPhoto');assert.match(reply.photo,/\/art\/bot-avatar-v1.jpg$/);assert.equal((await fetch(base+'/art/bot-avatar-v1.jpg')).status,200);
const duplicate=await api('/api/telegram/webhook',null,{update_id:id,message:{text:'/start',chat:{id:123,type:'private'}}},200,{'X-Telegram-Bot-Api-Secret-Token':'local-test-secret'});assert.equal(duplicate.ok,true);
console.log('PASS: static files, Telegram auth, expired/forged sessions, isolated saves, revision guard, origin guard, PvP/duo/raid reads, routing, webhook secret and duplicate protection.');
