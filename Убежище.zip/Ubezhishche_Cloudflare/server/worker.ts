import * as r0 from '../app/api/game/route';
import * as r1 from '../app/api/pvp/route';
import * as r2 from '../app/api/pvp/ranking/route';
import * as r3 from '../app/api/duo/route';
import * as r4 from '../app/api/raid/route';
import * as r5 from '../app/api/telegram/webhook/route';
const routes:Record<string,Record<string,(request:Request)=>Promise<Response>>>={'/api/game':r0,'/api/pvp':r1,'/api/pvp/ranking':r2,'/api/duo':r3,'/api/raid':r4,'/api/telegram/webhook':r5};
export default {async fetch(request:Request,env:Cloudflare.Env){const path=new URL(request.url).pathname;const route=routes[path];if(route){const handler=route[request.method];if(!handler)return new Response('Method not allowed',{status:405});return handler(request)}if(path.startsWith('/api/'))return Response.json({error:'Not found'},{status:404});return env.ASSETS.fetch(request)}};
