CREATE TABLE `pvp_matches` (
	`id` text PRIMARY KEY NOT NULL,
	`host` text NOT NULL,
	`guest` text,
	`status` text NOT NULL,
	`state` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_pvp_status_updated` ON `pvp_matches` (`status`,`updated_at`);--> statement-breakpoint
CREATE INDEX `idx_pvp_host` ON `pvp_matches` (`host`);--> statement-breakpoint
CREATE INDEX `idx_pvp_guest` ON `pvp_matches` (`guest`);--> statement-breakpoint
CREATE TABLE `pvp_slots` (
	`user_id` text PRIMARY KEY NOT NULL,
	`match_id` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_pvp_slots_match` ON `pvp_slots` (`match_id`);