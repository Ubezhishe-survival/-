CREATE TABLE `supply_grants` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`claimed_at` integer NOT NULL
);
