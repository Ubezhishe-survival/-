CREATE TABLE `duo_groups` (
	`id` text PRIMARY KEY NOT NULL,
	`host` text NOT NULL,
	`guest` text,
	`status` text NOT NULL,
	`state` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`updated_at` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_duo_host` ON `duo_groups` (`host`);--> statement-breakpoint
CREATE INDEX `idx_duo_guest` ON `duo_groups` (`guest`);--> statement-breakpoint
CREATE INDEX `idx_duo_expiry` ON `duo_groups` (`status`,`expires_at`);--> statement-breakpoint
CREATE TABLE `duo_slots` (
	`user_id` text PRIMARY KEY NOT NULL,
	`group_id` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_duo_slot_group` ON `duo_slots` (`group_id`);