import type {Game} from './game';
import {skinCatalog,type SkinId} from './expansion.ts';
export type Skin=SkinId;
export function equippedSkin(s:Pick<Game,'skin'|'ownedSkins'>):Skin{return s.skin&&Object.hasOwn(skinCatalog,s.skin)&&(s.skin==='survivor'||s.ownedSkins?.includes(s.skin))?s.skin:'survivor'}
