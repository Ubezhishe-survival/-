import {env} from 'cloudflare:workers';
import {validateTelegramInitData,TelegramAuthError} from './telegram-auth';
export {TelegramAuthError} from './telegram-auth';
export async function getPlayer(request:Request){const init=request.headers.get('X-Telegram-Init-Data');if(!init)return null;if(!env.TELEGRAM_BOT_TOKEN)throw new TelegramAuthError('Бот ещё не настроен.');return validateTelegramInitData(init,env.TELEGRAM_BOT_TOKEN)}
