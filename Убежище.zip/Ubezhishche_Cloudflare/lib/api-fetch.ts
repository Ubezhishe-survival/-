/** Bound both headers and body loading; never retry mutations automatically. */
export async function apiFetch(url:string,options:RequestInit={},timeoutMs=15000):Promise<Response>{
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{const response=await fetch(url,{...options,signal:controller.signal});const body=await response.arrayBuffer();return new Response(response.status===204?null:body,{status:response.status,statusText:response.statusText,headers:response.headers})}
 catch(error){if(controller.signal.aborted)throw new TypeError('Сервер отвечает слишком долго. Обнови данные перед повторным действием.');throw error}
 finally{clearTimeout(timer)}
}
