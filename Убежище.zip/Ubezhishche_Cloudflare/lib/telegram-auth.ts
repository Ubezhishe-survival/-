/** Telegram Mini Apps HMAC validation. No client profile is trusted before this. */
const encoder = new TextEncoder();
export class TelegramAuthError extends Error {}
async function hmac(key:Uint8Array, value:string){const imported=await crypto.subtle.importKey('raw',key as BufferSource,{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',imported,encoder.encode(value)));}
export function constantTimeEqual(a:string,b:string){if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0;}
export async function validateTelegramInitData(raw:string,token:string,now=Math.floor(Date.now()/1000)){
 if(!raw||raw.length>16384)throw new TelegramAuthError('Открой игру кнопкой в Telegram-боте.');
 const fields=new URLSearchParams(raw),keys=[...fields.keys()];
 if(new Set(keys).size!==keys.length)throw new TelegramAuthError('Некорректные данные входа.');
 const hash=fields.get('hash')||'';
 if(!/^[a-f0-9]{64}$/.test(hash))throw new TelegramAuthError('Не удалось проверить подпись Telegram.');
 fields.delete('hash');
 const check=[...fields.entries()].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>`${k}=${v}`).join('\n');
 const secret=await hmac(encoder.encode('WebAppData'),token);
 const expected=Array.from(await hmac(secret,check),n=>n.toString(16).padStart(2,'0')).join('');
 if(!constantTimeEqual(hash,expected))throw new TelegramAuthError('Не удалось проверить подпись Telegram.');
 const date=Number(fields.get('auth_date'));
 if(!Number.isSafeInteger(date)||date<=0||date>now+60||now-date>43200)throw new TelegramAuthError('Сессия завершена. Закрой игру и снова открой её в боте.');
 let user:{id:number;first_name?:string;username?:string;is_bot?:boolean};
 try{user=JSON.parse(fields.get('user')||'null')}catch{throw new TelegramAuthError('Некорректный профиль Telegram.')}
 if(!user||!Number.isSafeInteger(user.id)||user.id<=0||user.is_bot)throw new TelegramAuthError('Некорректный профиль Telegram.');
 return {userId:`telegram:${user.id}`,displayName:typeof user.first_name==='string'?user.first_name.slice(0,80):'Выживший',username:typeof user.username==='string'?user.username.toLowerCase():null,provider:'telegram' as const};
}
