import {applyMove,fighter,moveDamage,TURN_MS,type Duel,type Move} from './pvp';
export const arenaOpponents=[
 {id:'nate',name:'nate.wav',style:'pressure',portrait:'depot'},
 {id:'alex',name:'alex.r',style:'balanced',portrait:'tower'},
 {id:'mike',name:'mike77',style:'patient',portrait:'clinic'},
 {id:'karter',name:'Karter',style:'pressure',portrait:'tower'},
 {id:'den',name:'den404',style:'balanced',portrait:'depot'},
 {id:'riley',name:'Riley',style:'patient',portrait:'tower'},
 {id:'maxwell',name:'Maxwell',style:'balanced',portrait:'clinic'},
 {id:'daniel',name:'daniel',style:'pressure',portrait:'depot'}
] as const;
export type BotId=typeof arenaOpponents[number]['id'];
const random=()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296;
export function chooseBotMove(s:Duel,roll=random()):Move{
 const me=s.fighters[1]!,enemy=s.fighters[0],profile=arenaOpponents.find(b=>b.id===s.bot);
 if(!me||!profile)throw new Error('Unknown arena opponent');
 if(moveDamage('strike',enemy)>=enemy.hp)return 'strike';
 if(me.energy>=2&&moveDamage('heavy',enemy)>=enemy.hp)return 'heavy';
 if(me.energy>=1&&moveDamage('break',enemy)>=enemy.hp)return 'break';
 if(me.hp<=45&&(me.kits??1)>0&&me.energy>=1&&roll<.75)return 'heal';
 if(enemy.shield)return me.energy>=1?'break':'guard';
 if(enemy.evade)return 'strike';
 const caution=profile.style==='patient'?.65:profile.style==='balanced'?.4:.2;
 if(enemy.energy>=2&&roll<caution)return 'guard';
 if(enemy.energy===1&&me.energy>=1&&roll<caution)return 'dodge';
 if(me.energy>=2&&roll>(profile.style==='pressure'?.15:.4))return 'heavy';
 if(me.energy===0&&roll<caution)return 'guard';
 return 'strike';
}
export function botDuel(name:string,id:BotId,now:number):Duel{
 const bot=arenaOpponents.find(b=>b.id===id)!;return {fighters:[fighter(name),fighter(bot.name)],bot:id,botDue:0,turn:0,deadline:now+TURN_MS,winner:null,log:['Быстрый бой. Первый ход — твой.']};
}
export async function startPractice(db:D1Database,userId:string,name:string,botId:string,now:number){
 if(!arenaOpponents.some(b=>b.id===botId))return false;
 const id=crypto.randomUUID().replaceAll('-','').slice(0,12).toUpperCase(),state=botDuel(name,botId as BotId,now);
 await db.batch([
 db.prepare("INSERT INTO pvp_matches (id,host,guest,status,state,revision,updated_at,presence_at) VALUES (?,?,?,'active',?,0,?,?)").bind(id,userId,'arena:'+botId,JSON.stringify(state),now,now),
 db.prepare('INSERT INTO pvp_slots (user_id,match_id) VALUES (?,?)').bind(userId,id)
 ]);return true;
}
export async function tickOpponent(db:D1Database,userId:string,now:number){
 const r=await db.prepare('SELECT m.* FROM pvp_matches m JOIN pvp_slots s ON s.match_id=m.id WHERE s.user_id=? AND m.host=?').bind(userId,userId).first<{id:string;state:string;status:string;revision:number;updated_at:number}>();
 if(!r)return;
 let state=JSON.parse(r.state) as Duel,status=r.status,guest:string|undefined;
 if(status==='waiting'&&state.searching&&now-r.updated_at>=12_000){
  const bot=arenaOpponents[Math.floor(random()*arenaOpponents.length)];state=botDuel(state.fighters[0].name,bot.id,now);guest='arena:'+bot.id;status='active';
 }else if(status==='active'&&state.bot){
  if(state.turn===0){if(now<state.deadline)return;state.winner=1;state.log.unshift('Время твоего хода истекло.');status='finished';}
  else {if(now<(state.botDue??0))return;state=applyMove(state,1,chooseBotMove(state),Math.min(now,state.deadline-1));state.deadline=now+TURN_MS;state.botDue=0;if(state.winner!==null)status='finished';}
 }else return;
 await db.batch([
  db.prepare('UPDATE pvp_matches SET state=?,status=?,guest=COALESCE(?,guest),revision=revision+1,updated_at=? WHERE id=? AND revision=? AND status=?').bind(JSON.stringify(state),status,guest??null,now,r.id,r.revision,r.status),
  db.prepare("DELETE FROM pvp_slots WHERE match_id=? AND EXISTS (SELECT 1 FROM pvp_matches WHERE id=? AND status='finished')").bind(r.id,r.id)
 ]);
}
