import type {Mission} from './game';
export const missionIds:Mission[]=['clinic','depot','tower','market','metro','foundry'];
export const districtNames:Record<Mission,string>={clinic:'Больница',depot:'Депо',tower:'Эхо',market:'Рынок',metro:'Метро',foundry:'Литейная'};
export const prerequisites:Record<Mission,Mission[]>={clinic:[],depot:[],tower:['clinic','depot'],market:['depot'],metro:['tower'],foundry:['market','metro']};
export function missionLock(completed:Mission[],mission:Mission){const missing=prerequisites[mission].filter(id=>!completed.includes(id));return missing.length?`Сначала пройди: ${missing.map(id=>districtNames[id]).join(' и ')}.`:''}
export const districtArt:Record<Mission,string>={clinic:'location-clinic',depot:'location-depot',tower:'location-tower',market:'city-v2',metro:'bunker',foundry:'raid-steelworks'};
