import {fighter,TURN_MS,type Duel} from './pvp';
export async function searchOpponent(db:D1Database,userId:string,name:string,now:number){
 const id=crypto.randomUUID().replaceAll('-','').slice(0,12).toUpperCase();
 const state:Duel={searching:true,fighters:[fighter(name),null],turn:0,deadline:0,winner:null,log:['Поиск соперника. Оставайся на арене.']};
 const turn=crypto.getRandomValues(new Uint8Array(1))[0]%2;
 const fresh=now-15_000,waiting=now-10*60_000;
 // D1 batch is one transaction. Reserving the slot and starting the duel happen
 // together, so parallel searches cannot claim the same waiting opponent.
 await db.batch([
  db.prepare(`UPDATE pvp_matches SET status='cancelled',revision=revision+1
   WHERE id=(SELECT match_id FROM pvp_slots WHERE user_id=?) AND host=? AND status='waiting'
   AND EXISTS (SELECT 1 FROM pvp_matches other WHERE other.status='waiting' AND other.host<>? AND other.presence_at>? AND other.updated_at>?)`)
   .bind(userId,userId,userId,fresh,waiting),
  db.prepare("DELETE FROM pvp_slots WHERE user_id=? AND match_id IN (SELECT id FROM pvp_matches WHERE status='cancelled')").bind(userId),
  db.prepare(`INSERT INTO pvp_matches (id,host,status,state,revision,updated_at,presence_at)
   SELECT ?,?,'waiting',?,0,?,?
   WHERE NOT EXISTS (SELECT 1 FROM pvp_slots WHERE user_id=?)
   AND NOT EXISTS (SELECT 1 FROM pvp_matches WHERE status='waiting' AND host<>? AND presence_at>? AND updated_at>?)`)
   .bind(id,userId,JSON.stringify(state),now,now,userId,userId,fresh,waiting),
  db.prepare(`INSERT INTO pvp_slots (user_id,match_id)
   SELECT ?, (SELECT id FROM pvp_matches WHERE status='waiting' AND (host=? OR (presence_at>? AND updated_at>?)) ORDER BY updated_at,id LIMIT 1)
   WHERE NOT EXISTS (SELECT 1 FROM pvp_slots WHERE user_id=?)`)
   .bind(userId,userId,fresh,waiting,userId),
  db.prepare(`UPDATE pvp_matches SET guest=?,status='active',revision=revision+1,updated_at=?,
   state=json_set(state,'$.fighters[1]',json(?),'$.turn',?,'$.deadline',?,'$.log',json(?))
   WHERE id=(SELECT match_id FROM pvp_slots WHERE user_id=?) AND host<>? AND status='waiting' AND guest IS NULL`)
   .bind(userId,now,JSON.stringify(fighter(name)),turn,now+TURN_MS,JSON.stringify(['Соперник найден. Первый ход выбран случайно.']),userId,userId)
 ]);
}
