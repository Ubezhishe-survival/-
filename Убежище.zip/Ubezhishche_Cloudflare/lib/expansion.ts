import type {Game,Expedition,Mission} from './game';
export type RouteKind='safe'|'salvage'|'hunt';
export type EnemyKind='native'|'marauder'|'sniper'|'heavy';
export type Relic='counter'|'bulwark'|'scavenger'|'core';
export type SkinId='survivor'|'wasteland'|'ranger'|'warden';
export const routes={safe:{name:'Обходной путь',tag:'ОСТОРОЖНО',desc:'Обычный противник. Стандартная добыча.',hp:1,reward:1},salvage:{name:'Через руины',tag:'ПОИСК ПРИПАСОВ',desc:'Мародёр · +20% HP и +12% урона. На 35% больше боевой добычи.',hp:1.2,reward:1.35},hunt:{name:'Зона охоты',tag:'РЕДКАЯ НАХОДКА',desc:'Снайпер или штурмовик · +45% HP, сильнее удары. +80% боевой добычи и модуль локации.',hp:1.45,reward:1.8}} as const;
export const relics:Record<Relic,{name:string;desc:string;art:string;rarity:string}>={counter:{name:'Ответный импульс',desc:'+12 урона при атаке с фокусом. Для точных контратак.',art:'scope',rarity:'РЕДКИЙ'},bulwark:{name:'Пластина «Бастион»',desc:'Идеальный блок лечит 5 HP. Для долгих боёв.',art:'armor',rarity:'РЕДКИЙ'},scavenger:{name:'Разведкомплект',desc:'+25% добычи при возвращении. Для сбора припасов.',art:'backpack',rarity:'РЕДКИЙ'},core:{name:'Ядро Стража',desc:'+6 к каждому удару и −2 входящего урона.',art:'helmet',rarity:'ЭПИЧЕСКИЙ'}};
export const skinCatalog:Record<SkinId,{name:string;art:string;unlock:string;facesLeft?:boolean}>={survivor:{name:'Выживший',art:'fighter-survivor-real',unlock:'Доступен всем'},wasteland:{name:'Девушка пустоши',art:'skin-wasteland',unlock:'Персональный образ'},ranger:{name:'Следопыт',art:'fighter-survivor',unlock:'3 победных возвращения'},warden:{name:'Страж периметра',art:'fighter-raider',unlock:'Победа над совместным боссом',facesLeft:true}};
export function dayKey(now=Date.now()){return new Date(now+10800000).toISOString().slice(0,10)}
export const contracts=[{name:'Вернуться живым',desc:'Победи и вернись из одной вылазки.',kind:'extract',goal:1,reward:45},{name:'Точная тактика',desc:'Выполни 3 идеальных блока или уклонения.',kind:'perfect',goal:3,reward:35},{name:'Зачистка сектора',desc:'Победи двух противников в вылазках.',kind:'kill',goal:2,reward:60}] as const;
export function contractFor(key:string){return contracts[Math.floor(Date.parse(key+'T00:00:00Z')/86400000)%contracts.length]}
export function refreshDaily(s:Game,now:number){const key=dayKey(now);if(s.daily?.key!==key)s.daily={key,progress:0,claimed:false};}
export function progressDaily(s:Game,kind:string){if(s.daily&&contractFor(s.daily.key).kind===kind)s.daily.progress=Math.min(contractFor(s.daily.key).goal,s.daily.progress+1)}
export function enemyName(e:Expedition){return e.enemyKind==='sniper'?'Снайпер «Тень»':e.enemyKind==='heavy'?'Бронированный штурмовик':e.enemyKind==='marauder'?'Мародёр руин':null}
export function ownedRelic(s:Game){return s.relic&&s.relics?.includes(s.relic)?s.relic:null}
export const huntRelics:Record<Mission,Relic>={clinic:'bulwark',depot:'counter',tower:'scavenger',market:'scavenger',metro:'bulwark',foundry:'counter'};
export const duplicateScrap:Record<Mission,number>={clinic:10,depot:20,tower:35,market:25,metro:40,foundry:55};
export function rewardHunt(s:Game,mission:Mission){const next=huntRelics[mission];if(!s.relics?.includes(next)){s.relics=[...(s.relics??[]),next];return relics[next].name;}s.resources.scrap+=duplicateScrap[mission];return `дубликат обменян на ${duplicateScrap[mission]} деталей`}
