import type {Game,Action} from './game';
export type ResidentRole='mechanic'|'medic'|'scout'|'guard';
export type GuestKind=ResidentRole|'traveller'|'wounded'|'trader'|'intruder';
export type DoorGuest={id:string;kind:GuestKind;arrived:number;inspected:boolean;talked:boolean};
export type Camp={version:1;cursor:number;serial:number;nextDay:number;guest:DoorGuest|null;residents:{id:string;name:string;role:ResidentRole;joined:number}[];beds:number;supplied:boolean;helped:number;history:{day:number;name:string;text:string}[]};
export const roles:Record<ResidentRole,{name:string;benefit:string}>={mechanic:{name:'Механик',benefit:'+6 деталей после сытой ночи'},medic:{name:'Медик',benefit:'+8 HP к отдыху после сытой ночи'},scout:{name:'Разведчица',benefit:'+4 детали и 1 паёк за победное возвращение'},guard:{name:'Часовой',benefit:'+2 детали за сытую ночь; вдвое меньше потерь от вора'}};
type GuestInfo={name:string;label:string;quote:string;inspection:string;answer:string;aidLabel:string;aidCost:number;aidResource:'food'|'meds'|'scrap';aidResult:string};
export const guests:Record<GuestKind,GuestInfo>={
 mechanic:{name:'Марк',label:'Человек с ящиком инструментов',quote:'Ваш генератор слышно с дороги. Подшипник скоро сдаст. Дайте мне место — приведу всё в порядок.',inspection:'На ладонях масло и старые ожоги. В ящике ключи, тестер и аккуратно подписанные запчасти.',answer:'Работал в трамвайном депо. Проверишь меня на генераторе. Сначала ремонт, потом разговор о доверии.',aidLabel:'Дать паёк',aidCost:1,aidResource:'food',aidResult:'−1 паёк → +8 деталей. Марк оставит запчасти и уйдёт.'},
 traveller:{name:'Ася',label:'Путница с пустой флягой',quote:'До северного поста ещё день пути. Мне бы еды. Место у вас занимать не стану.',inspection:'Фляга пустая. На карте отмечен северный пост. В сумке несколько запечатанных бинтов.',answer:'Там ждёт мой брат. Бинты отдам за еду: идти без сил уже не могу.',aidLabel:'Поделиться едой',aidCost:2,aidResource:'food',aidResult:'−2 пайка → +2 медикамента. Ася продолжит путь.'},
 medic:{name:'Лев',label:'Мужчина с медицинской сумкой',quote:'Полевой госпиталь сгорел. Умею зашивать раны и ставить людей на ноги. Могу остаться у вас.',inspection:'Потрёпанный медицинский жетон. Инструменты стерильны, на сумке свежие следы копоти.',answer:'Начну с осмотра медблока. Чудес не обещаю, но после отдыха ты будешь восстанавливаться быстрее.',aidLabel:'Выдать медикаменты',aidCost:2,aidResource:'meds',aidResult:'−2 медикамента → +1 аптечка. Лев соберёт её и уйдёт.'},
 intruder:{name:'Глеб',label:'Незнакомец, называющий себя электриком',quote:'Могу починить проводку. Только откройте скорее — снаружи опасно.',inspection:'Вместо тестера — связка отмычек. Он рассматривает замок и камеру, а не кабели.',answer:'Из какого депо? Из южного… или восточного. Не помню номер. Зачем столько вопросов? Покажите склад.',aidLabel:'Передать паёк через шлюз',aidCost:1,aidResource:'food',aidResult:'−1 паёк. Дверь останется закрытой, незнакомец уйдёт.'},
 scout:{name:'Ира',label:'Разведчица с картой квартала',quote:'Знаю проходы между руинами. Пустите на ночлег — буду помогать вашим вылазкам.',inspection:'На карте свежие пометки завалов. Обувь изношена, но снаряжение содержится в порядке.',answer:'Сначала проверю подходы к больнице. После каждой вашей победы принесу немного деталей и еды.',aidLabel:'Дать еду в дорогу',aidCost:1,aidResource:'food',aidResult:'−1 паёк → +6 деталей. Ира оставит находки и уйдёт.'},
 wounded:{name:'Денис',label:'Раненый курьер',quote:'Зацепило об арматуру. Перевязать нечем. Я не прошу остаться, только помогите дойти до поста.',inspection:'На рукаве неглубокий порез. В сумке армейские пайки, оружия не видно.',answer:'Эти пайки везли на обмен. Возьмите три, если дадите бинты. Дальше пойду сам.',aidLabel:'Перевязать рану',aidCost:2,aidResource:'meds',aidResult:'−2 медикамента → +3 пайка. Курьер сможет продолжить путь.'},
 guard:{name:'Роман',label:'Бывший охранник каравана',quote:'Последний караван разошёлся. Могу держать ночную вахту и присматривать за складом.',inspection:'Оружие разряжено, магазин показан отдельно. На ремне жетон караванной охраны.',answer:'Начнём с периметра. Если внутрь проникнет вор, не дам ему вынести всё. На обходах собираю полезный металл.',aidLabel:'Снабдить в дорогу',aidCost:1,aidResource:'food',aidResult:'−1 паёк → +6 деталей. Роман оставит металл и уйдёт.'},
 trader:{name:'Сава',label:'Торговец с походным рюкзаком',quote:'Три пайка за двенадцать деталей. У двери обменяемся — мне ещё до темноты возвращаться.',inspection:'Упаковки целы. Вес припасов соответствует заявленному. Торговец держится на расстоянии от двери.',answer:'Ночлег не нужен. Детали пойдут на ремонт тележки. Можете проверить каждый паёк через шлюз.',aidLabel:'Обменять припасы',aidCost:12,aidResource:'scrap',aidResult:'−12 деталей → +3 пайка. Обмен без входа в убежище.'}
};
const order:GuestKind[]=['mechanic','traveller','medic','intruder','scout','wounded','guard','trader'];
export function ensureCamp(s:Game){
 if(!s.camp)s.camp={version:1,cursor:0,serial:0,nextDay:s.day,guest:null,residents:[],beds:0,supplied:true,helped:0,history:[]};
 const c=s.camp;if(s.visitor==='waiting'||s.expedition||c.guest||s.day<c.nextDay)return;
 let kind=order[c.cursor%order.length];c.cursor++;for(let i=0;i<order.length&&c.residents.some(r=>r.role===kind);i++){kind=order[c.cursor%order.length];c.cursor++;}c.serial++;c.guest={id:`door-${c.serial}`,kind,arrived:s.day,inspected:false,talked:false};
}
export const campCapacity=(s:Game)=>3+(s.camp?.beds??0);
export const campPopulation=(s:Game)=>(s.camp?.residents.length??0)+(s.visitor==='accepted'?1:0);
export const campFood=(s:Game)=>Math.ceil((s.camp?.residents.length??0)/2);
export function hasWorker(s:Game,role:ResidentRole){return !!s.camp?.supplied&&s.camp.residents.some(r=>r.role===role)}
export function nextBedCost(s:Game){return 60+(s.camp?.beds??0)*40}
export function isResidentRole(kind:GuestKind):kind is ResidentRole{return Object.hasOwn(roles,kind)}
function check(ok:unknown,message:string):asserts ok{if(!ok)throw new Error(message)}
function report(s:Game,text:string){s.message=text;s.journal.unshift({day:s.day,text});s.journal=s.journal.slice(0,60)}
export function campAction(s:Game,a:Action){
 check(!s.expedition,'Сначала вернись из вылазки.');ensureCamp(s);const c=s.camp!;
 if(a.type==='beds'){check(c.beds<2,'Все спальные места уже оборудованы.');const cost=nextBedCost(s);check(s.resources.scrap>=cost,`Нужно ${cost} деталей.`);s.resources.scrap-=cost;c.beds++;report(s,`Оборудовано новое спальное место. Вместимость: ${campCapacity(s)} жителей.`);return s;}
 if(a.type==='camp-feed'){const need=campFood(s);check(need>0&&!c.supplied,'Жители уже обеспечены едой.');check(s.resources.food>=need,`Нужно ${need} пайков.`);s.resources.food-=need;c.supplied=true;report(s,`Жителям выдано ${need} пайков. Они снова помогают убежищу. Ночные бонусы будут после отдыха.`);return s;}
 const g=c.guest;check(g&&a.target===g.id,'Посетитель уже ушёл. Обнови убежище.');const info=guests[g.kind];
 if(a.choice==='inspect'){check(!g.inspected,'Осмотр уже выполнен.');g.inspected=true;report(s,`${info.name}: ${info.inspection}`);return s;}
 if(a.choice==='talk'){check(!g.talked,'Разговор уже состоялся.');g.talked=true;report(s,`${info.name}: ${info.answer}`);return s;}
 check(['accept','aid','reject'].includes(a.choice??''),'Выбери решение у двери.');let result='';
 if(a.choice==='accept'){
  check(isResidentRole(g.kind)||g.kind==='intruder','Этот посетитель не просит поселения.');check(campPopulation(s)<campCapacity(s),'Нет свободных мест. Помоги через шлюз или оборудуй койку.');
  if(g.kind==='intruder'){const guarded=hasWorker(s,'guard'),loss=Math.min(s.resources.scrap,guarded?9:18),food=Math.min(s.resources.food,guarded?0:1);s.resources.scrap-=loss;s.resources.food-=food;result=`Незнакомец оказался вором и сбежал. Потеряно ${loss} деталей и ${food} пайков.${guarded?' Часовой ограничил потери.':' Отмычки и путаница в рассказе выдавали его.'}`;}
  else{check(!c.residents.some(r=>r.role===g.kind),'Такой специалист уже живёт в убежище.');c.residents.push({id:g.id,name:info.name,role:g.kind,joined:s.day});result=`${info.name} теперь живёт в убежище. ${roles[g.kind].benefit}. Еда для новых жителей: ${campFood(s)} пайков за ночь.`;}
 }else if(a.choice==='aid'){
  check(s.resources[info.aidResource]>=info.aidCost,'Не хватает припасов для помощи.');s.resources[info.aidResource]-=info.aidCost;
  if(g.kind==='mechanic')s.resources.scrap+=8;if(g.kind==='scout'||g.kind==='guard')s.resources.scrap+=6;if(g.kind==='traveller')s.resources.meds+=2;if(g.kind==='medic')s.kits++;if(g.kind==='wounded'||g.kind==='trader')s.resources.food+=3;
  if(g.kind!=='trader')c.helped++;result=`${info.name}: ${info.aidResult}`;
 }else result=`${info.name} ушёл. Дверь осталась закрытой; припасы сохранены.`;
 c.history.unshift({day:s.day,name:info.name,text:result});c.history=c.history.slice(0,8);c.guest=null;c.nextDay=s.day+2;report(s,result);return s;
}
export function campNight(s:Game){const c=s.camp;if(!c||!c.residents.length)return {heal:0,text:''};const need=campFood(s);c.supplied=s.resources.food>=need;if(!c.supplied)return {heal:0,text:`Жителям не хватило ${need} пайков. Их помощь приостановлена до выдачи еды.`};s.resources.food-=need;const scrap=(hasWorker(s,'mechanic')?6:0)+(hasWorker(s,'guard')?2:0);s.resources.scrap+=scrap;return {heal:hasWorker(s,'medic')?8:0,text:`Жители: −${need} пайков.${scrap?` Работа за ночь: +${scrap} деталей.`:''}${hasWorker(s,'medic')?' Медик: +8 HP к отдыху.':''}`}}
export function scoutReturn(s:Game){if(hasWorker(s,'scout')){s.resources.scrap+=4;s.resources.food++;return ' Разведчица принесла 4 детали и 1 паёк.'}return ''}
