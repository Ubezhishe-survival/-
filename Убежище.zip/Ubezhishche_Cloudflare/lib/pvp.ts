export type Move='strike'|'heavy'|'guard'|'break'|'dodge'|'heal';
export type Fighter={skin?:import('./expansion').SkinId;name:string;hp:number;energy:number;shield:boolean;evade?:boolean;kits?:number};
export type Duel={bot?:string;botDue?:number;searching?:boolean;round?:number;lastAction?:{seat:0|1;move:Move;damage:number;heal:number};fighters:[Fighter,Fighter|null];turn:0|1;deadline:number;winner:0|1|null;log:string[]};
export type MatchView={rewardClaimed?:boolean;id:string;status:'waiting'|'active'|'finished'|'cancelled';revision:number;updatedAt?:number;state:Duel;seat:0|1};
export const TURN_MS=90_000;
export const moves:Record<Move,{name:string;cost:number;description:string}>={
 strike:{name:'Удар',cost:0,description:'20 урона. Восстанавливает 1 энергию. Надёжный приём, когда нужно накопить силы.'},
 heavy:{name:'Выстрел',cost:2,description:'32 урона за 2 энергии. Самый сильный удар по открытой цели.'},
 break:{name:'Пробитие',cost:1,description:'12 урона сквозь блок. Снимает защиту и отнимает 1 энергию соперника. Уклонение спасает от урона, но не от потери энергии.'},
 guard:{name:'Защита',cost:0,description:'Поглощает 24 урона от следующей атаки и даёт 2 энергии. Пробитие обходит блок. Здоровье не восстанавливает.'},
 dodge:{name:'Манёвр',cost:1,description:'За 1 энергию снижает урон следующей атаки на 18, включая пробитие. Не даёт энергии и не лечит.'},
 heal:{name:'Аптечка',cost:1,description:'Восстанавливает до 24 HP за 1 энергию. Одна аптечка на дуэль. Расходует ход и снимает твою защиту.'}
};
export function fighter(name:string):Fighter{return {name:name.slice(0,32)||'Выживший',hp:100,energy:2,shield:false,evade:false,kits:1}}
export function unavailableMove(me:Fighter,move:Move):string|null{
 if(me.energy<moves[move].cost)return `Нужно ${moves[move].cost} энергии`;
 if(move==='heal'&&(me.kits??1)<=0)return 'Аптечка использована';
 if(move==='heal'&&me.hp>=100)return 'Здоровье полное';
 return null;
}
export function moveDamage(move:Move,enemy:Fighter){const base=move==='strike'?20:move==='heavy'?32:move==='break'?12:0;return Math.max(0,base-(move!=='break'&&enemy.shield?24:0)-(enemy.evade?18:0))}
export function applyMove(old:Duel,seat:0|1,move:Move,now:number):Duel {
 if(old.winner!==null||!old.fighters[1])throw new Error('Бой ещё не начался или уже завершён.');
 if(old.turn!==seat)throw new Error('Сейчас ход соперника.');
 if(now>=old.deadline)throw new Error('Время хода истекло.');
 if(!Object.hasOwn(moves,move))throw new Error('Неизвестный приём.');
 const s=structuredClone(old),me=s.fighters[seat]!,other=s.fighters[seat===0?1:0]!;
 const blocked=unavailableMove(me,move);if(blocked)throw new Error(blocked+'.');
 me.shield=false;me.evade=false;me.energy-=moves[move].cost;
 let damage=0,healed=0,detail='';
 if(move==='guard'){me.shield=true;me.energy=Math.min(3,me.energy+2);detail='блок 24 урона · +2 энергии';}
 else if(move==='dodge'){me.evade=true;detail='манёвр · −18 урона от следующей атаки';}
 else if(move==='heal'){healed=Math.min(24,100-me.hp);me.hp+=healed;me.kits=(me.kits??1)-1;detail=`+${healed} HP`;}
 else {damage=moveDamage(move,other);other.hp=Math.max(0,other.hp-damage);other.shield=false;other.evade=false;
  if(move==='strike')me.energy=Math.min(3,me.energy+1);
  if(move==='break')other.energy=Math.max(0,other.energy-1);
  detail=`−${damage} HP${move==='break'?' · срыв защиты и −1 энергия':''}`;if(other.hp===0)s.winner=seat;
 }
 s.lastAction={seat,move,damage,heal:healed};s.round=(s.round??0)+1;
 s.log.unshift(`${me.name}: ${moves[move].name.toLowerCase()} · ${detail}.`);
 s.turn=seat===0?1:0;s.deadline=now+TURN_MS;s.log=s.log.slice(0,12);return s;
}
