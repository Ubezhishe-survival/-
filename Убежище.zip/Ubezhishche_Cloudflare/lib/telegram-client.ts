export type TelegramApp={initData:string;platform:string;ready:()=>void;expand:()=>void;isVersionAtLeast:(v:string)=>boolean;setHeaderColor:(c:string)=>void;setBackgroundColor:(c:string)=>void;setBottomBarColor?:(c:string)=>void;enableClosingConfirmation?:()=>void;disableClosingConfirmation?:()=>void;BackButton:{show:()=>void;hide:()=>void;onClick:(f:()=>void)=>void;offClick:(f:()=>void)=>void};HapticFeedback?:{impactOccurred:(s:'light'|'medium')=>void;notificationOccurred:(t:'success'|'error'|'warning')=>void}};
declare global{interface Window{Telegram?:{WebApp:TelegramApp}}}
export function telegram(){return typeof window!=='undefined'?window.Telegram?.WebApp:undefined}
export function telegramHeaders():Record<string,string>{const init=telegram()?.initData;return init?{'X-Telegram-Init-Data':init}:{}}
let loading:Promise<void>|undefined;
export async function initTelegram(){
 if(!telegram()){
  loading??=new Promise<void>((resolve)=>{
   const script=document.createElement('script');script.src='https://telegram.org/js/telegram-web-app.js?64';script.async=true;
   const timer=setTimeout(resolve,6000);script.onload=()=>{clearTimeout(timer);resolve()};script.onerror=()=>{clearTimeout(timer);resolve()};document.head.appendChild(script);
  });await loading;
 }
 const app=telegram();if(!app?.initData)return false;
 app.ready();app.expand();
 if(app.isVersionAtLeast('6.1')){app.setHeaderColor('#11141c');app.setBackgroundColor('#11141c')}
 if(app.isVersionAtLeast('7.10'))app.setBottomBarColor?.('#191e2b');
 document.documentElement.classList.add('in-telegram');return true;
}
