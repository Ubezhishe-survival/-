export type BotUpdate={update_id?:number;message?:{text?:string;from?:{id?:number;is_bot?:boolean};chat?:{id?:number;type?:string}}};
export function botReply(update:BotUpdate,url:string){
 const message=update.message;
 if(!message||message.chat?.type!=='private'||!Number.isSafeInteger(message.chat.id)||message.from?.is_bot)return null;
 const command=(message.text||'').trim().split(/\s/)[0].split('@')[0].toLowerCase();
 if(!['/start','/play','/help'].includes(command))return null;
 const invite=(message.text||'').trim().split(/\s+/)[1]?.match(/^duo_([A-F0-9]{12})$/i);
 if(command==='/start'&&invite){const code=invite[1].toUpperCase(),destination=new URL(url);destination.searchParams.set('duo',code);return {method:'sendMessage',chat_id:message.chat.id,text:`📻 Тебя пригласили в отряд на двоих.\n\nКод группы: ${code}\nОткрой игру, присоединись и подтверди готовность.`,reply_markup:{inline_keyboard:[[{text:'Войти в группу',web_app:{url:destination.toString()}}]]}};}
 const reply_markup={inline_keyboard:[[{text:command==='/play'?'Продолжить выживание':'Войти в убежище',web_app:{url}}]]};
 if(command==='/help')return {method:'sendMessage',chat_id:message.chat.id,parse_mode:'HTML',text:'<b>ПАМЯТКА ВЫЖИВШЕГО</b>\n\n<b>Первый шаг</b> — осмотрись в убежище и отправляйся в Тихую больницу. Читай намерения противника перед ходом.\n\n🛡 Тяжёлый удар — блокируй.\n↪ Заход с фланга — уклоняйся.\n⚔ Враг восстанавливается — атакуй.\n\n<b>Дальше</b> — открывай районы, улучшай снаряжение, сражайся на арене. Для совместного рейда создай отряд и пригласи друга по ссылке.\n\nПрогресс сохраняется в твоём Telegram-аккаунте.',reply_markup};
 return {method:'sendPhoto',chat_id:message.chat.id,photo:new URL('/art/bot-avatar-v1.jpg',url).toString(),parse_mode:'HTML',caption:'<b>ПОСЛЕ СИГНАЛА</b>\n<i>Твоё убежище. Твоя частота. Твой шанс.</i>\n\nГород замолчал. Но в эфире ещё слышны голоса.\n\nРазвивай убежище и решай, кому открыть дверь. Исследуй опасные районы, собирай снаряжение и выбирай тактику боя.\n\n⚔ Дуэли на арене\n📻 Вылазки и рейды вдвоём\n◆ Снаряжение пяти редкостей\n\n<b>Первый сигнал уже ждёт.</b>',reply_markup};
}
