import type {Game} from './game';
import type {Duel} from './pvp';
export const PVP_REWARD={scrap:30,meds:1} as const;
export function pvpPrize(old:Game,match:{status:string;host:string;guest:string|null;state:string},userId:string){
 const seat=match.host===userId?0:match.guest===userId?1:null,state=JSON.parse(match.state) as Duel;
 if(seat===null||match.status!=='finished'||state.winner!==seat)throw new Error('Награда доступна только победителю завершённой дуэли.');
 const s=structuredClone(old);s.resources.scrap+=PVP_REWARD.scrap;s.resources.meds+=PVP_REWARD.meds;s.message='Победа на арене: +30 деталей и 1 медикамент.';s.journal.unshift({day:s.day,text:s.message});s.journal=s.journal.slice(0,60);return s;
}
export async function claimPvpPrize(db:D1Database,match:{id:string;status:string;host:string;guest:string|null;state:string},userId:string,now:number){
 const receipt=`pvp:${match.id}`;
 // Validate the winner even when an existing receipt is present.
 const row=await db.prepare('SELECT state,revision FROM game_saves WHERE user_id=?').bind(userId).first<{state:string;revision:number}>();if(!row)throw new Error('Сначала загрузи убежище.');
 const next=pvpPrize(JSON.parse(row.state),match,userId);
 const statements=[
  db.prepare('UPDATE game_saves SET state=?,revision=revision+1,updated_at=? WHERE user_id=? AND revision=? AND NOT EXISTS (SELECT 1 FROM supply_grants WHERE id=?)').bind(JSON.stringify(next),now,userId,row.revision,receipt),
  db.prepare('INSERT INTO supply_grants (id,user_id,claimed_at) SELECT ?,?,? WHERE changes()=1').bind(receipt,userId,now)
 ];
 const result=await db.batch(statements);if(result[0].meta.changes)return true;
 const claimed=await db.prepare('SELECT id FROM supply_grants WHERE id=? AND user_id=?').bind(receipt,userId).first();return !!claimed;
}
