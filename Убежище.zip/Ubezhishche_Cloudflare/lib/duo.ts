import type {Game,Mission,Resource} from './game';
export type DuoMode='raid'|'expedition';
export type DuoPhase='waiting'|'event'|'combat'|'victory'|'defeat'|'cancelled';
export type DuoMember={name:string;hp:number;focus:number;kits:number;ready:boolean;actions:number;damage:number;misses:number};
export type DuoState={mode:DuoMode;mission:Mission;phase:DuoPhase;members:[DuoMember,DuoMember|null];enemyHp:number;enemyMax:number;turn:0|1;round:number;event:number;votes:[string|null,string|null];deadline:number;bonus:{scrap:number;meds:number};log:string[];last?:{seat:0|1;move:string;hit:number;received:number}};
export type DuoView={id:string;revision:number;seat:0|1;state:DuoState;claimed:boolean;expires:number};
export const DUO_TURN_MS=90000;
export const duoLocations={market:{name:'Затопленный рынок',enemy:'Банда затопленного квартала',hp:380,damage:26,loot:{scrap:60,food:12,fuel:2,meds:3}},metro:{name:'Тоннели метро',enemy:'Охотники тоннелей',hp:440,damage:30,loot:{scrap:85,food:3,fuel:3,meds:10}},foundry:{name:'Литейный комплекс',enemy:'Охрана литейной',hp:520,damage:34,loot:{scrap:130,food:3,fuel:10,meds:4}},clinic:{name:'Тихая больница',enemy:'Стая скитальцев',hp:200,damage:16,loot:{scrap:25,food:2,fuel:0,meds:7}},depot:{name:'Грузовое депо',enemy:'Бригада сборщиков',hp:280,damage:22,loot:{scrap:55,food:3,fuel:7,meds:2}},tower:{name:'Станция «Эхо»',enemy:'Охрана передатчика',hp:360,damage:28,loot:{scrap:85,food:2,fuel:3,meds:4}}} as const;
export const duoEvents=[{title:'Разделиться у завала?',text:'Один прикроет проход, второй спустится за ящиком запчастей. Обход безопасен для обоих.',safe:'Обойти вместе',risk:'Достать ящик',cost:12,reward:'+12 деталей каждому'},{title:'Запертый медконтейнер',text:'Замок подключён к повреждённой проводке. Можно вскрыть контейнер вдвоём или продолжить путь.',safe:'Пройти мимо',risk:'Вскрыть вдвоём',cost:10,reward:'+2 медикамента каждому'}] as const;
export const duoMember=(name:string):DuoMember=>({name:name.slice(0,32)||'Выживший',hp:120,focus:0,kits:2,ready:false,actions:0,damage:0,misses:0});
export function newDuo(name:string,mode:DuoMode,mission:Mission):DuoState{const hp=mode==='raid'?480:duoLocations[mission].hp;return {mode,mission,phase:'waiting',members:[{...duoMember(name),ready:true},null],enemyHp:hp,enemyMax:hp,turn:0,round:0,event:0,votes:[null,null],deadline:0,bonus:{scrap:0,meds:0},log:['Группа создана. Пригласи второго игрока.']}}
export function duoIntent(s:DuoState){const pattern=s.mode==='raid'?['heavy','attack','open','heavy','open','attack']:s.mission==='tower'?['heavy','attack','heavy','open','open']:['heavy','attack','open'];return pattern[s.round%pattern.length] as 'heavy'|'attack'|'open'}
export function duoEnemyDamage(s:DuoState){return s.mode==='raid'?30:duoLocations[s.mission].damage}
export function duoLoot(s:DuoState):Record<Resource,number>&{kits:number}{const base=s.mode==='raid'?{scrap:100,food:3,fuel:2,meds:4}:duoLocations[s.mission].loot;return {...base,scrap:base.scrap+s.bonus.scrap,meds:base.meds+s.bonus.meds,kits:s.mode==='raid'?1:0}}
const check=(ok:unknown,message:string)=>{if(!ok)throw new Error(message)};
function log(s:DuoState,text:string){s.log.unshift(text);s.log=s.log.slice(0,12)}
function resolveEvent(s:DuoState,now:number){const risky=s.votes.every(v=>v==='risk'),event=duoEvents[s.event];if(risky){for(const p of s.members)p!.hp-=event.cost;if(s.event===0)s.bonus.scrap+=12;else s.bonus.meds+=2;log(s,`Вы рискнули вместе: −${event.cost} HP каждому, ${event.reward.toLowerCase()}.`)}else log(s,'Выбрали безопасный путь. Риск возможен только по согласию обоих.');s.event++;s.votes=[null,null];s.deadline=now+DUO_TURN_MS;if(s.event>=2){s.phase='combat';log(s,'Противник перекрыл путь. Ходит лидер группы.')}}
export function duoAction(old:DuoState,seat:0|1,action:string,choice:string|undefined,now:number):DuoState{
 const s=structuredClone(old),me=s.members[seat];check(me,'Ты не участник этой группы.');
 if(action==='ready'){check(s.phase==='waiting'&&seat===1,'Готовность меняет второй игрок до начала похода.');me!.ready=!me!.ready;return s}
 if(action==='start'){check(s.phase==='waiting'&&seat===0,'Поход запускает лидер группы.');check(s.members[1]?.ready,'Дождись готовности второго игрока.');s.phase=s.mode==='raid'?'combat':'event';s.deadline=now+DUO_TURN_MS;log(s,s.mode==='raid'?'Отряд вошёл на завод. Следите за намерением Стража.':'Отряд вышел за периметр. Решения принимаются вместе.');return s}
 if(action==='leave'){check(['waiting','event','combat'].includes(s.phase),'Поход уже завершён.');if(s.phase==='waiting'&&seat===1){s.members[1]=null;log(s,'Второй игрок покинул группу. Можно пригласить другого.')}else{s.phase=s.phase==='waiting'?'cancelled':'defeat';log(s,`${me!.name} покинул отряд. Поход завершён без награды.`)}return s}
 check(s.phase==='event'||s.phase==='combat','Поход ещё не начался или уже завершён.');
 if(action==='timeout'){
  check(now>=s.deadline,'Время ожидания ещё не вышло.');
  if(s.phase==='event'){for(const i of [0,1] as const)if(s.votes[i]===null){s.members[i]!.misses++;s.votes[i]='safe'}if(s.members.some(p=>p!.misses>=2)){s.phase='defeat';log(s,'Напарник дважды не ответил. Отряд вернулся без награды.')}else resolveEvent(s,now);return s;}
  check(seat!==s.turn,'Ожидай решения напарника о пропущенном ходе.');const absent=s.members[s.turn]!;absent.misses++;if(absent.misses>=2||me!.hp<=0){s.phase='defeat';log(s,me!.hp<=0?'Последний боец не ответил. Поход сорван.':'Два пропуска хода. Поход сорван.');return s;}log(s,`${absent.name} пропустил ход. Отряд прикрыл его от атаки.`);s.round++;s.turn=seat;s.deadline=now+DUO_TURN_MS;return s;
 }
 check(now<s.deadline,'Время решения вышло. Обнови группу.');
 if(action==='vote'){
  check(s.phase==='event','Событие уже завершилось.');check(choice==='safe'||choice==='risk','Выбери путь.');check(s.votes[seat]===null,'Ты уже выбрал путь.');if(choice==='risk')check(s.members.every(p=>p!.hp>duoEvents[s.event].cost),'У отряда недостаточно здоровья для риска.');s.votes[seat]=choice!;me!.actions++;if(s.votes.every(Boolean))resolveEvent(s,now);return s;
 }
 check(action==='move'&&s.phase==='combat','Действие недоступно.');check(s.turn===seat&&me!.hp>0,'Сейчас ход напарника.');check(['strike','guard','dodge','heal','assist'].includes(choice??''),'Неизвестный приём.');
 const partner=s.members[seat===0?1:0]!,intent=duoIntent(s);let hit=0,received=0;
 if(choice==='heal'||choice==='assist'){check(me!.kits>0,'Нет полевых аптечек.');const patient=choice==='heal'?me!:partner;check(patient.hp<120,'Здоровье уже полное.');me!.kits--;patient.hp=Math.min(120,patient.hp+35);log(s,`${me!.name}: ${choice==='assist'?'помощь напарнику':'аптечка'}, до +35 HP.`);}
 if(choice==='strike'){hit=Math.min(s.enemyHp,24+me!.focus*12+(intent==='open'?12:0));s.enemyHp-=hit;me!.damage+=hit;me!.focus=0;}
 if(s.enemyHp>0){const base=duoEnemyDamage(s);received=intent==='heavy'?(choice==='guard'?0:Math.round(base*1.6)):intent==='attack'?(choice==='dodge'?0:choice==='guard'?Math.ceil(base*.5):base):0;me!.hp=Math.max(0,me!.hp-received);if((intent==='heavy'&&choice==='guard')||(intent==='attack'&&choice==='dodge'))me!.focus=Math.min(2,me!.focus+1);if(received>0)me!.focus=0;}
 me!.actions++;s.last={seat,move:choice!,hit,received};log(s,`${me!.name}: ${choice==='strike'?`удар −${hit} HP`:choice==='guard'?'блок':choice==='dodge'?'уклонение':choice==='assist'?'поддержка':'лечение'}${received?`, получено ${received} урона`:''}.`);s.round++;s.deadline=now+DUO_TURN_MS;
 if(s.enemyHp===0){s.phase='victory';log(s,'Победа отряда. Каждый участник забирает свою награду.')}else if(s.members.every(p=>p!.hp<=0)){s.phase='defeat';log(s,'Оба бойца выбыли. Поход завершён без награды.')}else s.turn=partner.hp>0?(seat===0?1:0):seat;
 return s;
}
export function duoPrize(old:Game,s:DuoState,seat:0|1):Game{check(s.phase==='victory'&&(s.members[seat]?.actions??0)>0,'Нужны победа и личное участие в походе.');const next=structuredClone(old),loot=duoLoot(s);for(const k of ['scrap','food','fuel','meds'] as Resource[])next.resources[k]+=loot[k];next.kits+=loot.kits;next.message=`Поход вдвоём завершён: +${loot.scrap} деталей, ${loot.food} пайков, ${loot.fuel} топлива, ${loot.meds} медикаментов${loot.kits?', аптечка':''}.`;next.journal.unshift({day:next.day,text:next.message});next.journal=next.journal.slice(0,60);return next}
