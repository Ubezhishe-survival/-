import type {Expedition,Mission,Resource} from './game';
export type ChallengeId='quarantine'|'cargo'|'overload';
export type ChallengeRun={id:ChallengeId;mistakes:number};
export const challenges={
 quarantine:{mission:'clinic',name:'Карантин',rule:'Аптечки недоступны до возвращения. Победи и доставь образцы.',hp:1.25,reward:{scrap:30,food:0,fuel:0,meds:5},prize:'+30 деталей · +5 медикаментов'},
 cargo:{mission:'depot',name:'Хрупкий груз',rule:'Сохрани груз: блокируй тяжёлые удары и уклоняйся от фланга. Три ошибки лишают бонуса.',hp:1.3,reward:{scrap:45,food:2,fuel:4,meds:0},prize:'+45 деталей · +2 пайка · +4 топлива'},
 overload:{mission:'tower',name:'Перегрузка',rule:'Победи за 12 боевых ходов. Защита и манёвр тоже расходуют ход.',hp:1.15,reward:{scrap:70,food:0,fuel:3,meds:2},prize:'+70 деталей · +3 топлива · +2 медикамента'}
} as const;
export const locationChallenge:Partial<Record<Mission,ChallengeId>>={clinic:'quarantine',depot:'cargo',tower:'overload'};
export function challengeStatus(e:Expedition){
 const run=e.challenge;if(!run)return null;const c=challenges[run.id];
 const failed=run.id==='cargo'?run.mistakes>=3:run.id==='overload'?(e.turn>12||(e.turn===12&&e.stage!=='cleared')):false;
 const success=e.stage==='cleared'&&!failed;
 const progress=run.id==='cargo'?`Груз: ${Math.max(0,3-run.mistakes)}/3`:run.id==='overload'?`Ходы: ${e.turn}/12`:'Аптечки заблокированы';
 return {name:c.name,rule:c.rule,prize:c.prize,failed,success,progress};
}
export function grantChallenge(s:{resources:Record<Resource,number>;challengeWins?:Partial<Record<ChallengeId,number>>},e:Expedition){
 const status=challengeStatus(e);if(!status?.success)return null;
 const id=e.challenge!.id,c=challenges[id];for(const key of ['scrap','food','fuel','meds'] as Resource[])s.resources[key]+=c.reward[key];
 s.challengeWins={...s.challengeWins,[id]:(s.challengeWins?.[id]??0)+1};return `Испытание «${c.name}» пройдено: ${c.prize}.`;
}
