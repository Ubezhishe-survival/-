const MOSCOW_OFFSET=3*60*60*1000;
export function currentSeason(now=Date.now()){return new Date(now+MOSCOW_OFFSET).toISOString().slice(0,7)}
export function seasonBounds(key:string){
 if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(key))throw new Error('Некорректный сезон.');
 const [year,month]=key.split('-').map(Number);return {start:Date.UTC(year,month-1,1)-MOSCOW_OFFSET,end:Date.UTC(year,month,1)-MOSCOW_OFFSET};
}
export const rankingSql=`WITH limits AS (SELECT ? AS lo,? AS hi),games AS (
 SELECT host AS player, json_extract(state,'$.fighters[0].name') AS name,
 CASE WHEN json_extract(state,'$.winner')=0 THEN 1 ELSE 0 END AS won,updated_at,id
 FROM pvp_matches WHERE status='finished' AND json_extract(state,'$.bot') IS NULL AND guest IS NOT NULL AND updated_at>=(SELECT lo FROM limits) AND updated_at<(SELECT hi FROM limits)
 UNION ALL
 SELECT guest AS player,json_extract(state,'$.fighters[1].name') AS name,
 CASE WHEN json_extract(state,'$.winner')=1 THEN 1 ELSE 0 END AS won,updated_at,id
 FROM pvp_matches WHERE status='finished' AND json_extract(state,'$.bot') IS NULL AND guest IS NOT NULL AND updated_at>=(SELECT lo FROM limits) AND updated_at<(SELECT hi FROM limits)
), named AS (
 SELECT *,ROW_NUMBER() OVER(PARTITION BY player ORDER BY updated_at DESC,id DESC) AS recent FROM games
), totals AS (
 SELECT player,MAX(CASE WHEN recent=1 THEN name END) AS name,SUM(won) AS wins,COUNT(*)-SUM(won) AS losses,
 SUM(won)*30 AS points,MIN(CASE WHEN won=1 THEN updated_at END) AS first_win FROM named GROUP BY player
), ranked AS (
 SELECT *,ROW_NUMBER() OVER(ORDER BY points DESC,losses ASC,first_win ASC,player ASC) AS place FROM totals
)`;
export type RankRow={player:string;name:string;wins:number;losses:number;points:number;place:number};
export async function readRanking(db:D1Database,userId:string,key:string,now=Date.now()){
 const {start,end}=seasonBounds(key);
 const rows=await db.batch([
  db.prepare(rankingSql+' SELECT * FROM ranked ORDER BY place LIMIT 30').bind(start,end),
  db.prepare(rankingSql+' SELECT * FROM ranked WHERE player=?').bind(start,end,userId),
  db.prepare("SELECT DISTINCT strftime('%Y-%m',updated_at/1000+10800,'unixepoch') AS season FROM pvp_matches WHERE status='finished' AND json_extract(state,'$.bot') IS NULL ORDER BY season DESC LIMIT 12")
 ]);
 const present=(row:RankRow)=>({name:row.name,wins:row.wins,losses:row.losses,points:row.points,place:row.place,me:row.player===userId});
 return {season:key,current:currentSeason(now),start,end,now,rows:(rows[0].results as RankRow[]).map(present),mine:rows[1].results.length?present(rows[1].results[0] as RankRow):null,seasons:[...new Set([currentSeason(now),...(rows[2].results as {season:string}[]).map(r=>r.season)])]};
}
