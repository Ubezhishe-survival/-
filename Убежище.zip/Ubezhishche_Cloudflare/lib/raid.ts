import {dayKey} from './expansion.ts';
import type {Game} from './game';
export type Raider={name:string;hp:number;focus:number;moves:number;damage:number;nextAt:number;kits:number};
export type RaidState={hp:number;maxHp:number;members:Record<string,Raider>};
export function initialRaid():RaidState{return {hp:1200,maxHp:1200,members:{}}}
export function raidIntent(member:Raider){return member.moves%3===0?'heavy':member.moves%3===1?'attack':'open'}
export function raidAct(old:RaidState,user:string,name:string,move:string,now:number):RaidState{
 const s=structuredClone(old);if(s.hp<=0)throw new Error('Страж уже повержен. Забери награду.');
 if(move==='join'){if(s.members[user])return s;if(Object.keys(s.members).length>=100)throw new Error('Отряд заполнен. Новый рейд начнётся завтра.');s.members[user]={name:name.slice(0,32),hp:100,focus:0,moves:0,damage:0,nextAt:0,kits:2};return s;}
 const p=s.members[user];if(!p)throw new Error('Сначала присоединись к рейду.');if(p.hp<=0||p.moves>=20)throw new Error('Твои ходы закончились. Отряд может завершить бой.');if(now<p.nextAt)throw new Error('Подожди до следующего действия.');if(!['strike','guard','heal'].includes(move))throw new Error('Неизвестный приём.');
 if(move==='heal'){if(p.kits<=0||p.hp>=100)throw new Error('Аптечка недоступна.');p.kits--;p.hp=Math.min(100,p.hp+35);}
 const intent=raidIntent(p);let hit=0;
 if(move==='strike'){hit=Math.min(s.hp,35+p.focus*20);s.hp-=hit;p.damage+=hit;p.focus=0;}
 if(s.hp>0){const damage=move==='guard'?0:intent==='heavy'?35:intent==='attack'?12:0;p.hp=Math.max(0,p.hp-damage);if(move==='guard'&&intent!=='open')p.focus=Math.min(2,p.focus+1);}
 p.moves++;p.nextAt=now+4000;return s;
}
export function raidReward(old:Game,raid:RaidState,user:string,key:string,now:number):Game{
 if(key!==dayKey(now))throw new Error('Начался новый рейд.');if(raid.hp>0||(raid.members[user]?.damage??0)<100)throw new Error('Нужны победа отряда и не менее 100 личного урона.');
 if(old.raidReceipts?.includes(key))throw new Error('Награда уже получена.');
 const s=structuredClone(old);s.resources.scrap+=90;s.kits+=2;s.relics=Array.from(new Set([...(s.relics??[]),'core']));s.ownedSkins=Array.from(new Set([...(s.ownedSkins??[]),'warden']));s.raidReceipts=[...(s.raidReceipts??[]),key].slice(-60);s.message='Страж повержен: +90 деталей, 2 аптечки, Ядро Стража и образ Стража периметра.';return s;
}
