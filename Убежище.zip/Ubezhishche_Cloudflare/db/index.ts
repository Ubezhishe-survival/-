import { env } from 'cloudflare:workers';
export function database() { if(!env.DB) throw new Error('Save database unavailable'); return env.DB; }
