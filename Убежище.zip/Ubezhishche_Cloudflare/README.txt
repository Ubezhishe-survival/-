ПОСЛЕ СИГНАЛА / УБЕЖИЩЕ — отдельная версия Cloudflare

Полный комплект: исходники и изображения игры + исправление подключения 1.3.
Это исходники и изображения игры для СВОЕГО Telegram-бота.
Сохранения игроков с прежнего сервера не входят: новая база начинается пустой.
Оригинальная игра не меняется. Персональные подарки прежнему владельцу отключены.

ЧТО НУЖНО
Компьютер Windows/macOS/Linux, аккаунт Cloudflare, новый Telegram-бот.
На телефоне удобнее читать инструкцию, а команды выполнять на компьютере.
1. Node.js 24 LTS: https://nodejs.org/en/download
2. Python 3: https://www.python.org/downloads/ (Windows: включи Add Python to PATH).
3. Cloudflare: https://dash.cloudflare.com/sign-up
4. BotFather: https://t.me/BotFather — /newbot, придумай имя и username.
   Сохрани токен отдельно. Не публикуй его и не вставляй в исходники.

УСТАНОВКА
Распакуй архив. Открой терминал в папке с package.json (не внутри ZIP).
На Windows: открой папку, в адресной строке проводника набери cmd и Enter.
Команды выполняй по одной. При ошибке остановись и прочитай раздел ниже.

1) Установи зависимости:
   npm ci

2) Войди в Cloudflare (откроется браузер):
   npx wrangler login
   npx wrangler whoami

3) Создай НОВУЮ базу (имя можно заменить своим):
   npx wrangler d1 create after-signal-db
   Скопируй выданный database_id: это UUID, не API-токен.
   База также видна: dashboard → Storage & databases → D1.

4) Выбери адрес Worker.
   Dashboard → Compute → Workers & Pages. При первом использовании задай
   workers.dev subdomain своего аккаунта. Например, my-account.
   Придумай имя Worker, например my-shelter.
   Адрес будет https://my-shelter.my-account.workers.dev
   Настрой проект командой:
   npm run setup
   Введи имя Worker, имя базы, database_id, этот HTTPS адрес и username бота.
   Скрипт обновит wrangler.json и создаст .env. Токен здесь НЕ нужен.

5) Создай таблицы на Cloudflare:
   npm run db:remote
   Подтверди применение миграций. Должны пройти все 7 файлов.

6) Проверь и опубликуй игру:
   npm run check
   npm run deploy
   В конце появится реальный адрес Worker. Он должен совпадать с шагом 4.
   Если отличается: снова npm run setup с правильным адресом, затем npm run deploy.
   Бесплатный адрес workers.dev достаточен; покупать домен не нужно.

7) Задай секреты (ввод скрыт):
   npx wrangler secret put TELEGRAM_BOT_TOKEN
   Вставь токен НОВОГО бота из BotFather.
   npx wrangler secret put TELEGRAM_WEBHOOK_SECRET
   Введи случайную строку из 32–64 латинских букв/цифр. Сохрани её отдельно.
   Можно сгенерировать: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   Эта строка понадобится ещё раз при подключении бота.

8) Подключи бота через исправленную форму версии 1.3:
   Windows: дважды нажми CONNECT_BOT.cmd в распакованной папке проекта.
   Откроется окно «Убежище — подключение бота 1.3».
   Через кнопки «Вставить» введи:
   — токен НОВОГО бота из BotFather, тот же, что сохранён в Cloudflare;
   — ТОТ ЖЕ TELEGRAM_WEBHOOK_SECRET, который задан на шаге 7;
   — реальный HTTPS адрес Worker из результата npm run deploy.
   Нажми «Подключить бота». Дождись сообщения «ПОДКЛЮЧЕНО».
   Токен и секрет вводятся в форму, а не в команду или адрес браузера.

   Если окно не открылось, запусти из папки проекта:
   py -3 scripts/connect-gui.py
   либо: python scripts/connect-gui.py
   macOS/Linux: python3 scripts/connect-gui.py
   Если Tkinter недоступен, можно использовать консольный способ:
   python3 scripts/connect-telegram.py

   Подключатель проверяет токен, действующий webhook, Worker и секрет.
   Если у бота уже чужой webhook, он остановится: для отдельной установки
   используй нового бота. Ошибки и дополнительные варианты запуска
   описаны в CONNECTION_HELP_RU.txt.
   Исправление 1.3 уже включено: отдельный архив поверх накладывать не надо.

9) Открой своего бота в Telegram, нажми /start → «Войти в убежище».
   Пройди обучение; закрой и открой игру — прогресс должен сохраниться.
   Проверь со вторым аккаунтом: у него должно быть отдельное убежище.
   Для режима вдвоём отправь ему ссылку-приглашение из игры.
   Аватар бота при желании: BotFather → /setuserpic → public/art/bot-avatar-v1.jpg.

ОБНОВЛЕНИЯ
После изменения кода: npm run check, затем npm run deploy.
Не создавай заново базу и не меняй database_id: там сохранения игроков.
Перед обновлением сделай резервную копию:
   npx wrangler d1 export DB --remote --output backup.sql
Храни backup.sql приватно. В архив для передачи другим его не добавляй.
Для новых миграций: npm run db:remote, затем npm run deploy.

ЧАСТЫЕ ПРОБЛЕМЫ
• npm не найден: установи Node.js и заново открой терминал.
• Ошибка PowerShell про npm.ps1: используй cmd или npm.cmd.
• No such table: пропущен npm run db:remote или выбран другой database_id.
• «Открой игру в Telegram»: обычный браузер не передаёт подпись Telegram.
  Запускай через кнопку внутри своего бота; подделывать заголовки не нужно.
• «Бот ещё не настроен» / 503: проверь secrets и привязку DB в Worker.
• 401 в Telegram: токен Worker должен принадлежать именно открытому боту.
• Webhook Forbidden: разные TELEGRAM_WEBHOOK_SECRET в Cloudflare и скрипте.
• Ссылка ведёт к другому боту: снова setup и deploy, затем CONNECT_BOT.cmd (или scripts/connect-gui.py).
• Картинка не пришла: открой https://ТВОЙ-АДРЕС/art/bot-avatar-v1.jpg.
• Старая версия: закрой Mini App полностью, повторно открой кнопкой.
• Ошибки Worker: npx wrangler tail (не публикуй логи с личными данными).
• Ограничения сети: доступ к Cloudflare, npm и Telegram нужен на этапе установки.

БЕСПЛАТНЫЙ ТАРИФ
Архитектура рассчитана на Workers + D1, без платного домена и отдельного VPS.
Бесплатный тариф имеет квоты: нет обещания неограниченного онлайна.
PvP/отряды опрашивают сервер; рост онлайна увеличит расход запросов и D1.
Следи за Usage в панели. Реальная нагрузка и CPU на Cloudflare требуют замеров.
Актуальные условия:
https://developers.cloudflare.com/workers/platform/pricing/
https://developers.cloudflare.com/d1/platform/pricing/
https://developers.cloudflare.com/workers/static-assets/
https://developers.cloudflare.com/d1/get-started/
https://developers.cloudflare.com/workers/configuration/secrets/
https://core.telegram.org/bots/webapps

ЛОКАЛЬНАЯ ПРОВЕРКА ДЛЯ РАЗРАБОТЧИКА
Создай .dev.vars (он исключён из архива и git):
TELEGRAM_BOT_TOKEN=local-test-token
TELEGRAM_WEBHOOK_SECRET=local-test-secret
TELEGRAM_MINI_APP_URL=https://local-test.example
Выполни npm run build, npm run db:local, npm run dev.
В другом терминале той же папки: npm test.
Тест использует искусственные подписанные профили только на localhost:8787.
Не устанавливай эти тестовые секреты на публичный сервер.
Это проверка API, не полное автоматическое прохождение игры.
