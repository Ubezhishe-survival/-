'use client';
import {useState} from 'react';
import {Users,Radio} from 'lucide-react';
import CoopRaid from './coop-raid';
import DuoAdventure from './duo-adventure';
export default function RaidsHub({enabled,onClaim,invite}:{enabled:boolean;onClaim:()=>Promise<void>;invite:string}){const [tab,setTab]=useState<'duo'|'world'>('duo');return <section className="raids-hub"><div className="mode-switch" role="group" aria-label="Режим рейда"><button className={tab==='duo'?'selected':''} aria-pressed={tab==='duo'} onClick={()=>setTab('duo')}><Users size={16}/> Отряд · 2 игрока</button><button className={tab==='world'?'selected':''} aria-pressed={tab==='world'} onClick={()=>setTab('world')}><Radio size={16}/> Общий рейд</button></div>{tab==='duo'?<DuoAdventure enabled={enabled} mode="raid" onClaim={onClaim} invite={invite}/>:<CoopRaid onClaim={onClaim}/>}</section>}
