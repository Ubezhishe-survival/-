'use client';
import { Maximize2, RadioTower, Anvil, BatteryCharging, HeartPulse, Shield } from 'lucide-react';
import { roomInfo, type Game, type Room } from '../lib/game';
const roomIcons={radio:RadioTower,workshop:Anvil,generator:BatteryCharging,infirmary:HeartPulse};
export default function ShelterScene({game,expanded=false,onExpand,onRoom}:{game:Game;expanded?:boolean;onExpand?:()=>void;onRoom:(room:Room)=>void}){
 return <section className={'shelter-window '+(expanded?'is-expanded':'')} aria-label="Панорама убежища">
  <header className="shelter-window-header"><div><span className="eyebrow">ПОДЗЕМНЫЙ КОМПЛЕКС</span><h2>Убежище <span>07</span></h2></div>{!expanded&&<button className="shelter-expand" onClick={onExpand}><Maximize2 size={17}/><span>Развернуть</span></button>}</header>
  <div className="shelter-pan-scroll" tabIndex={expanded?0:undefined} aria-label={expanded?'Панорама: прокрути в сторону, чтобы рассмотреть комнаты':undefined}>
   <div className="shelter-panorama"><img src="/art/bunker-v2.webp" alt="Убежище в разрезе: радиорубка слева вверху, мастерская справа, генератор и медблок этажом ниже" width={1536} height={1024}/>
    {(Object.keys(roomIcons) as Room[]).map(r=>{const Icon=roomIcons[r];return <button key={r} className={'shelter-room-pin pin-room-'+r} onClick={()=>onRoom(r)} aria-label={`${roomInfo[r].name}, уровень ${game.rooms[r]}. Открыть улучшения`}><Icon size={16}/><span>{roomInfo[r].name}</span><b>{game.rooms[r]}</b></button>})}
   </div>
  </div>
  <div className="shelter-window-footer"><span><Shield size={14}/> Периметр закрыт</span><span>{expanded?'Листай панораму · нажми на комнату':'Нажми на комнату для улучшения'}</span></div>
 </section>
}
