'use client';
import {useState} from 'react';
import {Wrench,ShoppingBag,Check} from 'lucide-react';
import {shopOffers,type ShopItem,type Game,type Action} from '../lib/game';

export default function Shop({game,disabled,send}:{game:Game;disabled:boolean;send:(action:Action)=>Promise<void>}){
 const [count,setCount]=useState<1|5>(1);
 return <section className="supply-shop dense-shop"><div className="shop-toolbar"><span><Wrench size={14}/> {game.resources.scrap} деталей</span><div role="group" aria-label="Количество товаров">{([1,5] as const).map(n=><button key={n} aria-pressed={count===n} onClick={()=>setCount(n)} className={count===n?'selected':''}>{n} шт.</button>)}</div></div>
 <div className="supply-list">{(Object.keys(shopOffers) as ShopItem[]).map(key=>{const offer=shopOffers[key],cost=offer.cost*count,owned=key==='kit'?game.kits:game.resources[key],missing=Math.max(0,cost-game.resources.scrap);return <article key={key} className="supply-row">
 <img src={key==='kit'?'/art/item-kit.webp':`/art/shop-${key}.webp`} alt="" width={48} height={48} loading="lazy"/>
 <div className="supply-copy"><h2>{offer.name}</h2><span>В запасе: {owned}</span></div>
 <button className="secondary supply-buy" aria-label={`Купить ${offer.name}, ${count} шт. за ${cost} деталей`} disabled={disabled||!!game.expedition||missing>0} onClick={()=>void send({type:'buy',target:key,choice:String(count)})}><ShoppingBag size={14}/><b>{cost}</b><small>дет.</small></button>
 <details className="supply-info"><summary>{missing?`Не хватает ${missing} деталей · подробнее`:'Описание и применение'}</summary><p>{key==='kit'?`Восстанавливает до ${32+game.rooms.infirmary*8} HP. В вылазке не расходует ход.`:offer.description}</p><small>{offer.cost} деталей за штуку</small></details>
 </article>})}</div><p className="shop-footnote">Нажми на цену, чтобы купить выбранное количество.</p></section>
}
