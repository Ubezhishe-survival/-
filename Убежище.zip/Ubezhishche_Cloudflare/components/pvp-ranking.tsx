'use client';
import {useEffect,useRef,useState} from 'react';
import {Trophy,Medal,RotateCw} from 'lucide-react';
import {telegramHeaders} from '../lib/telegram-client';
type Standing={name:string;wins:number;losses:number;points:number;place:number;me:boolean};
type Rankings={season:string;current:string;start:number;end:number;now:number;rows:Standing[];mine:Standing|null;seasons:string[]};
const monthName=(key:string)=>new Date(key+'-15T12:00:00Z').toLocaleDateString('ru-RU',{month:'long',year:'numeric',timeZone:'Europe/Moscow'});
export default function PvpRanking(){
 const [data,setData]=useState<Rankings|null>(null),[selected,setSelected]=useState(''),[error,setError]=useState(''),[loading,setLoading]=useState(true);const seq=useRef(0),alive=useRef(true);
 async function refresh(){const ticket=++seq.current;try{const r=await fetch('/api/pvp/ranking'+(selected?'?season='+encodeURIComponent(selected):''),{headers:telegramHeaders(),cache:'no-store'});const d=await r.json() as Rankings & {error?:string};if(!r.ok)throw new Error(d.error);if(alive.current&&ticket===seq.current){setData(d);setError('')}}catch(e){if(alive.current&&ticket===seq.current)setError(e instanceof Error?e.message:'Нет связи с рейтингом.')}finally{if(alive.current&&ticket===seq.current)setLoading(false)}}
 useEffect(()=>{alive.current=true;setLoading(true);setData(null);void refresh();const timer=setInterval(()=>{if(document.visibilityState==='visible')void refresh()},15000);return()=>{alive.current=false;seq.current++;clearInterval(timer)}},[selected]);
 return <section className="rankings" aria-label="Месячный рейтинг PvP">
  <div className="season-heading"><div><span className="eyebrow amber">МЕСЯЧНЫЙ СЕЗОН</span><h2>{data?monthName(data.season):'Рейтинг арены'}</h2></div><Trophy size={34}/></div>
  <label className="season-select">Сезон<select value={selected} onChange={e=>setSelected(e.target.value)}><option value="">Текущий сезон</option>{data?.seasons.filter(k=>k!==data.current).map(k=><option key={k} value={k}>{monthName(k)}</option>)}{selected&&!data&&<option value={selected}>{monthName(selected)}</option>}</select></label>
  {error&&<div className="pvp-error" role="alert">{error}<button className="text-button" onClick={()=>void refresh()}><RotateCw size={16}/> Обновить</button></div>}
  {loading&&!data?<p role="status">Загружаем рейтинг…</p>:data&&<>
   <div className="season-personal"><div className="rank-emblem"><Medal size={35}/></div><div><span className="eyebrow">ТВОЙ РЕЗУЛЬТАТ</span><h3>{data.mine?`№ ${data.mine.place}`:'Ещё нет боёв'}</h3><p>{data.mine?`${data.mine.wins} побед · ${data.mine.losses} поражений`:'Заверши дуэль, чтобы попасть в таблицу.'}</p></div><strong>{data.mine?.points??0}<small>очков</small></strong></div>
   <p className="season-deadline">{data.season===data.current?<>До конца сезона: <b>{Math.max(1,Math.ceil((data.end-data.now)/86400000))} дн.</b> Новый сезон — {new Date(data.end).toLocaleDateString('ru-RU',{day:'numeric',month:'long',timeZone:'Europe/Moscow'})}, 00:00 МСК.</>:<>Сезон завершён. Результаты сохранены.</>}</p>
   <div className="pvp-panel ranking-table"><div className="ranking-table-title"><h3>Лучшие бойцы</h3><span>ТОП 30</span></div>{data.rows.length?<ol>{data.rows.map(row=><li key={row.place} className={row.me?'is-me':''}><span className={'rank-number place-'+row.place}>{row.place<=3?<Trophy size={19}/>:row.place}<span className="sr-only">Место {row.place}</span></span><div className="rank-player"><b>{row.name}{row.me&&<em>ты</em>}</b><small>{row.wins} побед · {row.losses} поражений</small></div><strong>{row.points}<small>очков</small></strong></li>)}</ol>:<div className="pvp-empty"><Trophy size={32}/><p>Новый сезон — новая вершина. Заверши первый бой и займи место в рейтинге.</p></div>}</div>
   <p className="pvp-hint">Победа: +30 очков. Поражение: 0. При равных очках выше игрок с меньшим числом поражений, затем — с более ранней первой победой. Считаются завершённые рейтинговые PvP-дуэли, включая победы по времени. Быстрые бои не учитываются. Бой относится к месяцу его завершения.</p><p className="pvp-hint">Первого числа в 00:00 по Москве все начинают новый сезон с нуля. Прошлые результаты доступны в выборе сезона. Таблица обновляется каждые 15 секунд.</p>
  </>}
 </section>
}
