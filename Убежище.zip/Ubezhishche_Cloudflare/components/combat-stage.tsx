'use client';
import {skinCatalog,type SkinId} from '../lib/expansion';
import {memo,useEffect,useRef,useState} from 'react';
import {Shield,Wind,Cross} from 'lucide-react';
export type StageMove='strike'|'heavy'|'break'|'guard'|'dodge'|'heal';
export type StageAction={id:string|number;actor:0|1;move:StageMove;damage:number;heal?:number;counterDamage?:number;counterMove?:StageMove};
export type StageFighter={name:string;hp:number;maxHp:number;skin?:SkinId;art?:string;shield?:boolean;evade?:boolean};
const names:Record<StageMove,string>={strike:'Удар',heavy:'Мощная атака',break:'Пробитие',guard:'Защита',dodge:'Уклонение',heal:'Аптечка'};
function CombatStage({fighters,location='depot',action,title='Контакт',turn=0}:{fighters:[StageFighter,StageFighter];location?:string;action?:StageAction;title?:string;turn?:number}){
 const last=useRef(action?.id),[playing,setPlaying]=useState<StageAction|null>(null),[phase,setPhase]=useState<'first'|'counter'>('first');
 useEffect(()=>{
  if(!action){setPlaying(null);return}if(action.id===last.current)return;last.current=action.id;setPlaying(action);setPhase('first');
  const counter=action.counterDamage!==undefined?setTimeout(()=>setPhase('counter'),820):undefined;
  const end=setTimeout(()=>setPlaying(null),action.counterDamage!==undefined?1750:1000);
  return()=>{clearTimeout(counter);clearTimeout(end)};
 },[action?.id]);
 const actor=playing?(phase==='counter'?(playing.actor===0?1:0):playing.actor):null;
 const move=playing?(phase==='counter'?playing.counterMove??'strike':playing.move):null;
 const damage=playing?(phase==='counter'?playing.counterDamage??0:playing.damage):0;
 const attack=move==='strike'||move==='heavy'||move==='break';
 const key=`${playing?.id}-${phase}`;
 return <div className={'combat-cinema '+(playing?'is-playing':'')} aria-label="Анимированная сцена боя">
  <div className="cinema-scoreboard">{fighters.map((f,i)=><div className={'cinema-score side-'+i} key={i}><b title={f.name}>{f.name}</b><div><strong>{f.hp}<small> / {f.maxHp}</small></strong><span>{f.shield?<Shield size={14}/>:f.evade?<Wind size={14}/>:null}</span></div><div className="cinema-health" role="meter" aria-label={`Здоровье: ${f.name}`} aria-valuemin={0} aria-valuemax={f.maxHp} aria-valuenow={f.hp}><i style={{width:`${Math.max(0,f.hp)/f.maxHp*100}%`}}/></div></div>)}</div>
  <div className={`cinema-world ${attack&&damage>0?'impact-world':''}`}>
   <img className="cinema-background" src={`/art/location-${location}.webp`} alt=""/>
   <div className="cinema-depth"/>
   <div className="cinema-scene-label"><span>{title}</span><span>ХОД {turn+1}</span></div>
   {[0,1].map(i=>{const f=fighters[i],skin=f.skin?skinCatalog[f.skin]:null,flip=skin?(!!skin.facesLeft!==(i===1)):false,acting=actor===i,receiving=actor!==null&&!acting&&attack;
    const response=phase==='counter'&&playing?playing.move:null;
    const pose=acting?`move-${move}`:receiving?(response==='dodge'?'move-dodge':response==='guard'?'receive-block':damage>0?'receive-hit':'receive-block'):'';
    return <div key={i} className={`cinema-fighter fighter-${i} ${pose} ${f.hp<=0?'fighter-down':''}`}>
     <div className="cinema-ground-shadow"/><div className={"cinema-body "+(flip?'skin-face-left':'')}><img src={f.art?`/art/${f.art}.webp`:skin?`/art/${skin.art}.webp`:`/art/fighter-${i===0?'survivor':'raider'}-real.webp`} alt={f.skin==='wasteland'?'Девушка пустоши':i===0?'Выживший в боевой стойке':'Рейдер в боевой стойке'} draggable={false}/></div>
     {(f.shield||pose==='receive-block'||pose==='move-guard')&&<span className="cinema-shield" aria-hidden="true"><Shield/></span>}
     {(pose==='move-dodge')&&<span className="cinema-dodge" aria-hidden="true"><Wind/></span>}
     {acting&&move==='heal'&&<span className="cinema-heal" aria-hidden="true"><Cross/></span>}
     {receiving&&damage>0&&<span className="cinema-impact" aria-hidden="true"/>}
     {receiving&&<strong key={key} className={'cinema-number '+(damage===0?'blocked':'')}>{damage?`−${damage}`:response==='dodge'?'УКЛОНЕНИЕ':'БЛОК'}</strong>}
     {acting&&move==='heal'&&<strong className="cinema-number restored">+{playing?.heal??0}</strong>}
    </div>})}
   {attack&&<div key={key} className={`cinema-trail from-${actor} trail-${move}`} aria-hidden="true"/>}
   <div className={'cinema-action-caption '+(playing?'visible':'')} aria-live="polite">{playing&&move?<><span>{actor===0?'ТЫ':'ПРОТИВНИК'}</span><b>{names[move]}</b></>:<b>Выбери свой приём</b>}</div>
  </div>
 </div>
}

export default memo(CombatStage,(a,b)=>a.location===b.location&&a.title===b.title&&a.turn===b.turn&&JSON.stringify(a.action)===JSON.stringify(b.action)&&a.fighters.every((f,i)=>JSON.stringify(f)===JSON.stringify(b.fighters[i])));
