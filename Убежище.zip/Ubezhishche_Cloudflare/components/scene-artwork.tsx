'use client';
import {memo} from 'react';
import type { Mission } from '../lib/game';
const scenes:Record<Mission,{src:string;alt:string}>={
 clinic:{src:'/art/location-clinic.webp',alt:'Заброшенная больница: пустой приёмный зал и освещённый коридор'},
 depot:{src:'/art/location-depot.webp',alt:'Грузовое депо: старые вагоны, рельсы и топливные бочки'},
 market:{src:'/art/location-market.webp',alt:'Затопленный район рынка'},metro:{src:'/art/location-metro.webp',alt:'Подземные коммуникации метро'},foundry:{src:'/art/location-foundry.webp',alt:'Заброшенный литейный завод'},
 tower:{src:'/art/location-tower.webp',alt:'Станция «Эхо»: радиомачта и передатчики над городом'}
};
export default memo(function SceneArtwork({location,stage='map'}:{location:Mission;stage?:string}){
 const scene=scenes[location];
 return <div className={'scene-artwork stage-'+stage}><img key={location} className="scene-layer visible" src={scene.src} alt={scene.alt} decoding="async"/><div className="scene-vignette" aria-hidden="true"/></div>
});
