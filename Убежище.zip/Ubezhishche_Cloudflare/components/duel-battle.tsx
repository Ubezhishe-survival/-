'use client';
import {useState} from 'react';
import {Swords,Crosshair,Shield,ShieldOff,Wind,Cross,Zap,Clock3,ChevronDown,Trophy,Flag} from 'lucide-react';
import {moves,moveDamage,unavailableMove,type MatchView,type Move} from '../lib/pvp';
import CombatStage from './combat-stage';
const icons={strike:Swords,heavy:Crosshair,break:ShieldOff,guard:Shield,dodge:Wind,heal:Cross};
const order:Move[]=['strike','heavy','break','guard','dodge','heal'];
export default function DuelBattle({match,clock,busy,send,onExit}:{match:MatchView;clock:number;busy:boolean;send:(action:string,id?:string,move?:Move)=>void;onExit:()=>void}){
 const [selected,setSelected]=useState<Move>('strike'),[confirm,setConfirm]=useState(false);
 const s=match.state,seat=match.seat,me=s.fighters[seat]!,enemy=s.fighters[seat===0?1:0]!,myTurn=s.turn===seat,finished=match.status==='finished',won=s.winner===seat;
 const seconds=Math.max(0,Math.min(90,Math.ceil((s.deadline-clock)/1000))),reason=unavailableMove(me,selected),canMove=!busy&&!finished&&myTurn&&seconds>0;
 const last=s.lastAction;
 const damage=moveDamage(selected,enemy),healing=Math.min(24,100-me.hp);

 const preview=selected==='guard'?'Блок 24 урона · +2 энергии':selected==='dodge'?'Снизит следующую атаку на 18':selected==='heal'?`Восстановит ${healing} HP · ${me.kits??1} аптечка`:`${damage} урона${selected==='strike'?' · +1 энергия':selected==='break'?' · −1 энергия врагу':''}`;
 return <section className={'duel-screen '+(finished?'duel-finished':'')} aria-label="Поле боя">
  <header className="duel-topline"><span>{s.bot?'Быстрый бой':'Дуэль'}</span><span>{finished?'Бой завершён':`Раунд ${Math.floor((s.round??0)/2)+1}`}</span></header>
  <div className="duel-stage cinematic-duel">
   <CombatStage fighters={[{...me,maxHp:100},{...enemy,maxHp:100}]} turn={s.round??0} title={finished?'Бой завершён':'Грузовое депо'} action={last?{id:`${match.id}:${s.round??match.revision}`,actor:last.seat===seat?0:1,move:last.move,damage:last.damage,heal:last.heal}:undefined}/>
   <div className="cinema-energy-row">{[me,enemy].map((f,i)=><div key={i}><Zap size={14}/><span>{f.energy}/3 энергии</span><small><Cross size={13}/>{f.kits??1}</small></div>)}</div>
  </div>
  <div className="duel-command">
   {finished?<div className={'duel-outcome '+(won?'victory':'defeat')}><Trophy size={34}/><span className="eyebrow">ДУЭЛЬ ЗАВЕРШЕНА</span><h2>{won?'Победа':'Поражение'}</h2><p>{won?(match.rewardClaimed?'Награда получена: 30 деталей и 1 медикамент.':'Твоя награда: 30 деталей и 1 медикамент.'):'Меняй тактику и попробуй ещё раз.'}</p>{won&&<button className="primary pvp-prize" disabled={busy||match.rewardClaimed} onClick={()=>send('reward',match.id)}>{match.rewardClaimed?'Награда получена':busy?'Получаем награду…':'Забрать награду'}</button>}<button className="secondary" onClick={onExit}>Вернуться на арену</button></div>:<>
   <div className={'duel-turn-strip '+(myTurn?'your-turn':'')}><div><i/><b>{seconds===0?(myTurn?'Время вышло':'Ожидаем результат'):myTurn?'Выбери приём':'Ход соперника'}</b></div><span className={seconds<15?'time-low':''}><Clock3 size={14}/>{seconds} сек.</span></div><div className="duel-clock-track"><i style={{width:`${seconds/90*100}%`}}/></div>
   <div className="duel-action-grid" role="group" aria-label="Выбор боевого приёма">{order.map(move=>{const Icon=icons[move],unavailable=unavailableMove(me,move);const short=move==='guard'?'+2 энергии':move==='dodge'?'−18 входящего урона':move==='heal'?`${me.kits??1} на бой`:`${moveDamage(move,enemy)} урона`;return <button key={move} className={`duel-action ${selected===move?'selected':''} ${unavailable?'unavailable':''}`} aria-pressed={selected===move} disabled={busy} onClick={()=>setSelected(move)} aria-label={`${moves[move].name}, ${short}${unavailable?', '+unavailable:''}`}><span className="duel-action-icon"><Icon size={19}/></span><span><b>{moves[move].name}</b><small>{short}</small></span><em>{moves[move].cost?<><Zap size={11}/>{moves[move].cost}</>:'0'}</em></button>})}</div>
   <div className="duel-selected" aria-live="polite"><div><b>{moves[selected].name}</b><span>{reason??preview}</span></div><p>{moves[selected].description}</p></div>
   <button className="primary duel-commit" disabled={!canMove||!!reason} onClick={()=>send('move',match.id,selected)}>{busy?'Передаём ход…':!myTurn?'Ждём соперника':seconds===0?'Время хода истекло':reason??`Применить: ${moves[selected].name.toLowerCase()}`}</button>
   {seconds===0&&!myTurn&&!s.bot&&<button className="secondary duel-claim" disabled={busy} onClick={()=>send('timeout',match.id)}>Засчитать победу по времени</button>}
   </>}
  </div>
  <div className="duel-bottom"><div className="duel-last-event" aria-live="polite">{last?<><span>{last.seat===seat?'Ты':'Соперник'}</span><b>{moves[last.move].name}</b><small>{last.damage?`−${last.damage} HP`:last.heal?`+${last.heal} HP`:'Приём выполнен'}</small></>:<span>Побеждает тот, кто первым снизит здоровье противника до нуля.</span>}</div>
   <details className="duel-log"><summary>Ход боя <ChevronDown size={14}/></summary><ol>{s.log.slice(0,8).map((line,i)=><li key={i}>{line}</li>)}</ol><p>Одна аптечка на дуэль. Блок и манёвр действуют до следующей атаки или твоего нового действия. Любой приём расходует ход. Максимум 3 энергии.</p></details>
   {!finished&&(confirm?<div className="duel-retreat"><p>Отступление засчитается как поражение.</p><button className="secondary" disabled={busy} onClick={()=>send('surrender',match.id)}>Отступить</button><button className="text-button" onClick={()=>setConfirm(false)}>Остаться</button></div>:<button className="text-button duel-retreat-link" onClick={()=>setConfirm(true)}><Flag size={13}/> Отступить</button>)}
  </div>
 </section>
}
