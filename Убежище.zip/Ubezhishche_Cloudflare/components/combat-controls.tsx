'use client';
import {Swords,Shield,Activity,Crosshair,Zap} from 'lucide-react';
import {intent,intentText,attackDamage,openBonus,missions,type Game,type Action} from '../lib/game';
const titles={heavy:'Тяжёлый удар',open:'Открытая цель',attack:'Атака с фланга'};
export default function CombatControls({game,disabled,send}:{game:Game;disabled:boolean;send:(a:Action)=>void}){
 const e=game.expedition!;const move=intent(e),focus=e.focus??0,next=intent({...e,turn:e.turn+1});
 return <div className="tactical-controls">
  <div className="enemy-title"><span className="eyebrow danger">КОНТАКТ / ХОД {e.turn+1}</span><Crosshair size={19}/></div><h2>{missions[e.mission].enemy}</h2>
  <div className="enemy-hp"><span>Противник</span><b><span className="value-pop" key={e.enemyHp}>{e.enemyHp}</span> / {e.enemyMax}</b></div><div className="bar enemy"><i style={{width:`${e.enemyHp/e.enemyMax*100}%`}}/></div>
  <div className={'intent tactical-intent '+move} key={e.turn}><span className="intent-emblem">{move==='heavy'?<Shield/>:move==='open'?<Crosshair/>:<Activity/>}</span><div><span className="eyebrow">НАМЕРЕНИЕ ПРОТИВНИКА</span><b>{intentText(e)}</b><span>{move==='heavy'?'Блокируй: уклонение не спасёт от тяжёлого удара.':move==='open'?`Окно для атаки: +${openBonus(game)} урона, враг не отвечает.`:'Уклонись: получишь концентрацию без потери HP.'}</span></div></div>
  <div className="focus-meter"><span><Zap size={16}/> Концентрация</span><div aria-label={`${focus} из 2`}>{[1,2].map(n=><i className={n<=focus?'charged':''} key={n}/>)}</div><b>+{focus*8} урона</b></div>
  <div className="combat-buttons tactical-buttons"><button className={move==='open'?'recommended':''} disabled={disabled} onClick={()=>send({type:'fight',choice:'attack'})}><Swords/><b>Удар</b><small>{attackDamage(game)} урона</small>{move==='open'&&<em>Время атаковать</em>}</button><button className={move==='heavy'?'recommended':''} disabled={disabled} onClick={()=>send({type:'fight',choice:'guard'})}><Shield/><b>Защита</b><small>Блок тяжёлого</small>{move==='heavy'&&<em>Лучший ответ</em>}</button><button className={move==='attack'?'recommended':''} disabled={disabled} onClick={()=>send({type:'fight',choice:'dodge'})}><Activity/><b>Уклонение</b><small>Уход с фланга</small>{move==='attack'&&<em>Лучший ответ</em>}</button></div>
  <div className="next-intent"><span>Следом: <b>{titles[next]}</b></span><details className="combat-explainer"><summary>О концентрации</summary><p>Удачная защита или манёвр: +1 концентрация. Следующий удар её расходует. Сильный полученный урон сбивает её.</p></details></div>
 </div>
}
