import {ShieldCheck,AlertTriangle,FlaskConical} from 'lucide-react';
import {challengeStatus} from '../lib/challenges';
import type {Expedition} from '../lib/game';
export default function ChallengeStatus({expedition}:{expedition:Expedition}){
 const status=challengeStatus(expedition);if(!status)return null;
 const Icon=status.failed?AlertTriangle:status.success?ShieldCheck:FlaskConical;
 return <div className={'challenge-status '+(status.failed?'failed':status.success?'complete':'')} role="status"><Icon size={17}/><div><b>{status.name} · {status.progress}</b><p>{status.failed?'Условие нарушено. Обычную добычу ещё можно доставить домой.':status.success?`Условие выполнено. Вернись за бонусом: ${status.prize}`:status.rule}</p></div></div>;
}
