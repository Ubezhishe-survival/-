import {Gem} from 'lucide-react';
import {qualities,qualityLevel,qualityBonus,qualityLabel,qualityUpgrade,type GearSlot} from '../lib/gear-quality';
import type {Game,Action} from '../lib/game';
export default function QualityUpgrade({game,slot,disabled,send}:{game:Game;slot:GearSlot;disabled:boolean;send:(a:Action)=>void}){
 const current=qualityLevel(game,slot),u=qualityUpgrade(game,slot);
 return <div className="quality-upgrade"><b className={'rarity-'+qualities[current].key}><Gem size={14}/> {qualities[current].name}{current>0&&<span> · {qualityLabel(slot,qualityBonus(game,slot))}</span>}</b>{u?<><p>Следующая редкость: <strong className={'rarity-'+qualities[u.next].key}>{qualities[u.next].name}</strong><br/>{qualityLabel(slot,u.bonus)} суммарно · прирост {qualityLabel(slot,u.gain)}</p><button className="secondary" disabled={disabled||!!game.expedition||!!u.reason} onClick={()=>send({type:'quality',target:slot})}><Gem size={14}/> Повысить редкость</button><small>{u.cost.scrap} деталей{u.cost.meds?` · ${u.cost.meds} медикамента`:''}{u.cost.fuel?` · ${u.cost.fuel} топлива`:''}</small>{u.reason&&<small>{u.reason}</small>}</>:<p>Максимальная редкость. Бонус работает в одиночных вылазках.</p>}</div>;
}
