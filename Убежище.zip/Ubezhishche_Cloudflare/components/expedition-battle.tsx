'use client';
import ChallengeStatus from './challenge-status';
import {enemyName} from '../lib/expansion';
import {equippedSkin} from '../lib/skins';
import {useState} from 'react';
import {Swords,Shield,Wind,Cross,Flag,ChevronDown,Zap,House,Package,Check} from 'lucide-react';
import CombatStage,{type StageAction} from './combat-stage';
import {intent,attackDamage,openBonus,maxHp,missions,type Game,type Action} from '../lib/game';
const labels={heavy:'Сокрушающий удар',attack:'Атака с фланга',open:'Противник открыт'};
export default function ExpeditionBattle({game,disabled,send,action,onHelp}:{game:Game;disabled:boolean;send:(a:Action)=>void;action?:StageAction;onHelp:()=>void}){
 const [retreat,setRetreat]=useState(false);const e=game.expedition!,m=missions[e.mission],move=intent(e),won=e.stage==='cleared',focus=e.focus??0;
 const recommended=move==='heavy'?'guard':move==='attack'?'dodge':'attack';
 const choices=[{id:'attack',name:'Удар',desc:`${attackDamage(game)} урона`,Icon:Swords},{id:'guard',name:'Защита',desc:'Блок тяжёлого',Icon:Shield},{id:'dodge',name:'Манёвр',desc:'Уход с фланга',Icon:Wind}];
 return <section className="field-battle" aria-label="Боевой режим">
  <header className="field-header"><div><span>ВЫЛАЗКА · {won?'ПОБЕДА':`ХОД ${e.turn+1}`}</span><h1>{m.name}</h1></div><button onClick={onHelp} aria-label="Правила боя">?</button></header>
  <div className="field-scene"><CombatStage location={e.mission} title={won?'Путь свободен':'Контакт'} turn={e.turn} fighters={[{name:'Ты',hp:game.hp,maxHp:maxHp(game),skin:equippedSkin(game)},{name:enemyName(e)??m.enemy,hp:e.enemyHp,maxHp:e.enemyMax,art:e.enemyKind==='sniper'?'enemy-sniper':e.enemyKind==='heavy'?'enemy-heavy':undefined}]} action={action}/></div>
  <ChallengeStatus expedition={e}/><div className="field-console">{won?<div className="field-victory"><Check size={22}/><div><h2>Противник повержен</h2><p>Доставь найденные припасы домой.</p></div><button className="primary" disabled={disabled} onClick={()=>send({type:'extract'})}><House size={17}/> Забрать добычу</button></div>:<>
   <div className={'field-intent intent-'+move}><span className="field-intent-icon">{move==='heavy'?<Shield/>:move==='attack'?<Wind/>:<Swords/>}</span><div><small>СЛЕДУЮЩЕЕ ДЕЙСТВИЕ ВРАГА</small><b>{labels[move]}</b><p>{move==='heavy'?'Защита остановит удар. Манёвр не спасёт.':move==='attack'?'Манёвр позволит избежать урона.':`Атакуй: +${openBonus(game)} урона без ответного удара.`}</p></div></div>
   <div className="field-actions" role="group" aria-label="Боевые действия">{choices.map(({id,name,desc,Icon})=><button key={id} className={recommended===id?'suggested':''} disabled={disabled} onClick={()=>send({type:'fight',choice:id})}><Icon size={20}/><b>{name}</b><span>{desc}</span>{recommended===id&&<i aria-label="Рекомендуемый приём"/>}</button>)}</div>
   <div className="field-utilities"><div className="field-focus"><Zap size={15}/><span>Фокус</span><b>{focus}/2</b><small>+{focus*8} к удару</small></div><button disabled={disabled||!game.kits||game.hp>=maxHp(game)||e.challenge?.id==='quarantine'} onClick={()=>send({type:'heal'})}><Cross size={15}/><span>{e.challenge?.id==='quarantine'?'Карантин':'Аптечка'}</span><b>{game.kits}</b></button></div>
   <div className="field-turn-result" role="status">{action?disabled?'Выполняется приём…':e.log[0]:'Твой ход. Подсвечен подходящий ответ.'}</div>
  </>}
  <details className="field-details"><summary><Package size={15}/> Добыча и ход боя <ChevronDown size={15}/></summary><div className="field-loot"><span>Детали <b>{e.loot.scrap}</b></span><span>Пайки <b>{e.loot.food}</b></span><span>Топливо <b>{e.loot.fuel}</b></span><span>Медикаменты <b>{e.loot.meds}</b></span></div><ol>{e.log.slice(0,5).map((line,i)=><li key={i}>{line}</li>)}</ol><p>Удачный блок или манёвр добавляет фокус. Следующий удар расходует его. Сильный входящий урон сбивает фокус.</p></details>
  {!won&&(retreat?<div className="field-retreat"><p>Вернуться с уже найденной добычей? {e.challenge&&'Бонус испытания без победы не выдаётся.'}</p><button disabled={disabled} onClick={()=>send({type:'extract'})}>Да, отступить</button><button onClick={()=>setRetreat(false)}>Продолжить бой</button></div>:<button className="field-retreat-link" onClick={()=>setRetreat(true)}><Flag size={13}/> Отступить</button>)}
  </div>
 </section>
}
