'use client';
import {useState} from 'react';
import {Shield,Swords} from 'lucide-react';
import {missions,type Mission} from '../lib/game';
export default function EnemyPortrait({mission,small=false,action='',defeated=false}:{mission:Mission;small?:boolean;action?:string;defeated?:boolean}){
 const [failed,setFailed]=useState(false);
 return <div className={`enemy-portrait ${small?'compact':''} ${defeated?'defeated':''} react-${action}`}>
  {!failed?<img src={`/art/enemy-${mission}.webp`} alt={missions[mission].enemy} onError={()=>setFailed(true)} draggable={false}/>:<div className="enemy-fallback"><Swords size={48}/><span>{missions[mission].enemy}</span></div>}
  <div className="portrait-rim" aria-hidden="true"/>
  {!small&&<span className="enemy-rank">{mission==='tower'?'БОСС':mission==='depot'?'ЭЛИТА':'СКИТАЛЕЦ'}</span>}
  {action==='guard'&&!small&&<span className="portrait-block" aria-hidden="true"><Shield size={60}/></span>}
 </div>
}
